"""One-attempt access guard for the hash-frozen retrieval evaluation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from rag_mvp.freeze_guard import sha256_file


def begin_formal_attempt(
    *, binding_path: Path, configuration_path: Path, attempt_path: Path
) -> dict[str, Any]:
    binding = json.loads(binding_path.read_text(encoding="utf-8"))
    if binding.get("state") != "sealed_ready_for_formal_retrieval":
        raise PermissionError("formal retrieval binding is not ready")
    freeze_path = Path(str(binding["eval_freeze_path"]))
    if not freeze_path.is_file() or sha256_file(freeze_path) != binding.get(
        "eval_freeze_sha256"
    ):
        raise PermissionError("evaluation freeze hash mismatch")
    if not configuration_path.is_file() or sha256_file(configuration_path) != binding.get(
        "selected_configuration_sha256"
    ):
        raise PermissionError("selected retrieval configuration hash mismatch")
    if binding.get("formal_attempts_allowed") != 1 or binding.get(
        "formal_attempts_started"
    ) != 0:
        raise PermissionError("formal retrieval attempt is unavailable")
    if attempt_path.exists():
        raise PermissionError("formal retrieval attempt has already started")
    attempt = {
        "schema_version": 1,
        "attempt_id": "eval-v1-retrieval-sequence-1",
        "state": "started",
        "started_at": "2026-09-02T00:00:00+02:00",
        "binding_sha256": sha256_file(binding_path),
        "selected_configuration_sha256": sha256_file(configuration_path),
        "rerun_allowed": False,
    }
    attempt_path.parent.mkdir(parents=True, exist_ok=True)
    with attempt_path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(attempt, indent=2) + "\n")
    return attempt


def complete_formal_attempt(*, attempt_path: Path, terminal_report_path: Path) -> None:
    attempt = json.loads(attempt_path.read_text(encoding="utf-8"))
    if attempt.get("state") != "started":
        raise PermissionError("formal retrieval attempt is not in started state")
    if not terminal_report_path.is_file():
        raise FileNotFoundError("formal retrieval terminal report is missing")
    attempt.update(
        {
            "state": "completed_sealed",
            "completed_at": "2026-09-02T00:00:00+02:00",
            "terminal_report_path": terminal_report_path.as_posix(),
            "terminal_report_sha256": sha256_file(terminal_report_path),
        }
    )
    temporary = attempt_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(attempt, indent=2) + "\n", encoding="utf-8")
    temporary.replace(attempt_path)
