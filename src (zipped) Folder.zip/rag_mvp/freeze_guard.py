"""Fail-closed validation and access control for frozen evaluation artifacts."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any


DEVELOPMENT_DISTRIBUTION = {
    "direct_factual": 5,
    "paraphrase_or_terminology": 3,
    "high_similarity_distractor": 3,
    "cross_document_synthesis": 3,
    "conflict_or_version_boundary": 2,
    "insufficient_evidence_or_injection": 4,
}

FROZEN_TEST_DISTRIBUTION = {
    "direct_factual": 15,
    "paraphrase_or_terminology": 10,
    "high_similarity_distractor": 10,
    "cross_document_synthesis": 10,
    "conflict_or_version_boundary": 5,
    "insufficient_evidence_or_injection": 10,
}

REQUIRED_FIELDS = {
    "case_id",
    "question",
    "expected_evidence_ids",
    "accepted_evidence_groups",
    "expected_source_paths",
    "required_claims",
    "evidence_status",
    "requires_refusal",
    "category",
    "difficulty",
    "acceptable_answer_boundary",
    "label_review",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path}:{line_number} is not a JSON object")
        records.append(value)
    return records


def _chunk_catalog(chunks_path: Path) -> dict[str, dict[str, Any]]:
    rows = load_jsonl(chunks_path)
    catalog = {str(row["chunk_id"]): row for row in rows}
    if len(catalog) != len(rows):
        raise ValueError("corpus chunks contain duplicate IDs")
    return catalog


def validate_case_set(
    *,
    cases_path: Path,
    chunks_path: Path,
    expected_count: int,
    expected_distribution: dict[str, int],
) -> list[dict[str, Any]]:
    cases = load_jsonl(cases_path)
    if len(cases) != expected_count:
        raise ValueError(f"expected {expected_count} cases in {cases_path}, found {len(cases)}")
    catalog = _chunk_catalog(chunks_path)
    case_ids: set[str] = set()
    questions: set[str] = set()
    categories: Counter[str] = Counter()

    for case in cases:
        missing = REQUIRED_FIELDS - case.keys()
        if missing:
            raise ValueError(f"case is missing fields: {sorted(missing)}")
        case_id = str(case["case_id"])
        question = str(case["question"]).strip()
        if not case_id or case_id in case_ids:
            raise ValueError(f"duplicate or empty case ID: {case_id}")
        folded_question = question.casefold()
        if not question or folded_question in questions:
            raise ValueError(f"duplicate or empty question: {question}")
        case_ids.add(case_id)
        questions.add(folded_question)
        categories[str(case["category"])] += 1

        evidence_ids = case["expected_evidence_ids"]
        evidence_groups = case["accepted_evidence_groups"]
        source_paths = case["expected_source_paths"]
        claims = case["required_claims"]
        if (
            not isinstance(evidence_ids, list)
            or not isinstance(evidence_groups, list)
            or not isinstance(source_paths, list)
        ):
            raise ValueError(f"evidence fields must be lists: {case_id}")
        if (
            len(evidence_ids) != len(source_paths)
            or len(evidence_ids) != len(evidence_groups)
            or len(evidence_ids) != len(set(evidence_ids))
        ):
            raise ValueError(f"evidence identity/path mismatch: {case_id}")
        actual_paths: list[str] = []
        for evidence_id in evidence_ids:
            row = catalog.get(str(evidence_id))
            if row is None:
                raise ValueError(f"unknown evidence ID in {case_id}: {evidence_id}")
            actual_paths.append(str(row["source_path"]))
        if actual_paths != [str(path) for path in source_paths]:
            raise ValueError(f"evidence source paths are incorrect: {case_id}")
        for primary_id, source_path, group in zip(
            evidence_ids, source_paths, evidence_groups, strict=True
        ):
            if not isinstance(group, list) or not group or primary_id not in group:
                raise ValueError(f"invalid accepted evidence group: {case_id}")
            if len(group) != len(set(group)):
                raise ValueError(f"duplicate ID in accepted evidence group: {case_id}")
            for alternative_id in group:
                row = catalog.get(str(alternative_id))
                if row is None or str(row["source_path"]) != str(source_path):
                    raise ValueError(f"invalid alternative evidence: {case_id}")

        refusal = bool(case["requires_refusal"])
        status = str(case["evidence_status"])
        if status == "insufficient":
            if not refusal or evidence_ids or evidence_groups or claims:
                raise ValueError(f"insufficient-evidence contract mismatch: {case_id}")
        elif status == "sufficient":
            if not evidence_ids or not claims:
                raise ValueError(f"sufficient-evidence case lacks evidence or claims: {case_id}")
            if refusal and case["category"] != "insufficient_evidence_or_injection":
                raise ValueError(f"refusal is only valid for the injection category: {case_id}")
        else:
            raise ValueError(f"unknown evidence status: {case_id}")
        if case["category"] == "cross_document_synthesis" and len(set(source_paths)) < 2:
            raise ValueError(f"synthesis case is not cross-document: {case_id}")

        review = case["label_review"]
        if not isinstance(review, dict):
            raise ValueError(f"label review must be an object: {case_id}")
        if review.get("status") != "accepted" or review.get("ambiguity") != "none":
            raise ValueError(f"case has not passed ambiguity review: {case_id}")
        if not str(case["acceptable_answer_boundary"]).strip():
            raise ValueError(f"case has no answer boundary: {case_id}")

    if dict(categories) != expected_distribution:
        raise ValueError(f"category distribution mismatch: {dict(categories)}")
    return cases


def assert_no_case_leakage(
    *,
    development_path: Path,
    frozen_test_path: Path,
    chunks_path: Path,
) -> None:
    cases = load_jsonl(development_path) + load_jsonl(frozen_test_path)
    corpus_text = "\n".join(str(row["text"]) for row in load_jsonl(chunks_path)).casefold()
    for case in cases:
        if str(case["case_id"]).casefold() in corpus_text:
            raise ValueError(f"case ID leaked into corpus: {case['case_id']}")
        if str(case["question"]).casefold() in corpus_text:
            raise ValueError(f"case question leaked into corpus: {case['case_id']}")


def build_eval_freeze_manifest(
    *,
    development_path: Path,
    frozen_test_path: Path,
    chunks_path: Path,
    corpus_freeze_path: Path,
    author_script_path: Path,
    guard_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    development = validate_case_set(
        cases_path=development_path,
        chunks_path=chunks_path,
        expected_count=20,
        expected_distribution=DEVELOPMENT_DISTRIBUTION,
    )
    frozen_test = validate_case_set(
        cases_path=frozen_test_path,
        chunks_path=chunks_path,
        expected_count=60,
        expected_distribution=FROZEN_TEST_DISTRIBUTION,
    )
    assert_no_case_leakage(
        development_path=development_path,
        frozen_test_path=frozen_test_path,
        chunks_path=chunks_path,
    )
    corpus_freeze = json.loads(corpus_freeze_path.read_text(encoding="utf-8"))
    if corpus_freeze.get("freeze_id") != "corpus-v1-r2":
        raise ValueError("unexpected corpus freeze")
    manifest = {
        "schema_version": 1,
        "freeze_id": "eval-v1-r3",
        "frozen_at": "2026-08-29T00:00:00+08:00",
        "corpus_freeze_sha256": sha256_file(corpus_freeze_path),
        "chunks_sha256": sha256_file(chunks_path),
        "development": {
            "path": development_path.as_posix(),
            "sha256": sha256_file(development_path),
            "count": len(development),
            "distribution": DEVELOPMENT_DISTRIBUTION,
        },
        "frozen_test": {
            "path": frozen_test_path.as_posix(),
            "sha256": sha256_file(frozen_test_path),
            "count": len(frozen_test),
            "distribution": FROZEN_TEST_DISTRIBUTION,
        },
        "author_script": {
            "path": author_script_path.as_posix(),
            "sha256": sha256_file(author_script_path),
        },
        "freeze_guard": {
            "path": guard_path.as_posix(),
            "sha256": sha256_file(guard_path),
        },
        "label_review": {
            "status": "accepted",
            "ambiguous_cases": 0,
            "method": "path/index/phrase evidence assertion plus deterministic schema review",
        },
        "access_control": {
            "state": "sealed_unopened_for_selection",
            "selected_configuration_sha256": None,
            "formal_attempts": 0,
            "allowed_formal_attempts": 1,
        },
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return manifest


def validate_eval_freeze_manifest(
    *,
    freeze_manifest_path: Path,
    corpus_freeze_path: Path,
    chunks_path: Path,
) -> dict[str, Any]:
    manifest = json.loads(freeze_manifest_path.read_text(encoding="utf-8"))
    if manifest.get("freeze_id") != "eval-v1-r3":
        raise ValueError("unexpected evaluation freeze ID")
    if manifest.get("corpus_freeze_sha256") != sha256_file(corpus_freeze_path):
        raise ValueError("corpus freeze hash mismatch")
    if manifest.get("chunks_sha256") != sha256_file(chunks_path):
        raise ValueError("chunks hash mismatch")
    for key in ("development", "frozen_test"):
        entry = manifest[key]
        path = Path(str(entry["path"]))
        if not path.is_file() or sha256_file(path) != entry["sha256"]:
            raise ValueError(f"{key} hash mismatch")
    for key in ("author_script", "freeze_guard"):
        entry = manifest.get(key)
        if not isinstance(entry, dict):
            raise ValueError(f"{key} evidence is missing")
        path = Path(str(entry["path"]))
        if not path.is_file() or sha256_file(path) != entry.get("sha256"):
            raise ValueError(f"{key} hash mismatch")
    return manifest


def assert_frozen_test_access(
    *,
    freeze_manifest_path: Path,
    configuration_path: Path,
) -> None:
    manifest = json.loads(freeze_manifest_path.read_text(encoding="utf-8"))
    control = manifest.get("access_control", {})
    expected_hash = control.get("selected_configuration_sha256")
    if control.get("state") != "sealed_ready_for_formal_retrieval":
        raise PermissionError("frozen test is not bound to a selected retrieval configuration")
    if not expected_hash or not configuration_path.is_file():
        raise PermissionError("selected retrieval configuration is missing")
    if sha256_file(configuration_path) != expected_hash:
        raise PermissionError("selected retrieval configuration hash mismatch")
    if control.get("formal_attempts") != 0 or control.get("allowed_formal_attempts") != 1:
        raise PermissionError("frozen formal attempt is no longer available")
