"""Development-set retrieval benchmark orchestration."""

from __future__ import annotations

import json
import math
import time
from pathlib import Path
from typing import Any

from rag_mvp.freeze_guard import load_jsonl, sha256_file
from rag_mvp.retrieval_metrics import aggregate_retrieval_metrics, score_retrieval_case
from rag_mvp.schemas import Chunk


def load_chunks(path: Path) -> list[Chunk]:
    return [Chunk(**record) for record in load_jsonl(path)]


def percentile(values: list[float], percentile_value: float) -> float:
    if not values:
        raise ValueError("cannot compute a percentile from no values")
    if not 0 <= percentile_value <= 1:
        raise ValueError("percentile must be between 0 and 1")
    ordered = sorted(values)
    index = max(0, math.ceil(percentile_value * len(ordered)) - 1)
    return ordered[index]


def benchmark_retriever(
    *,
    candidate_name: str,
    retriever,
    cases_path: Path,
    chunks_path: Path,
    top_ks: tuple[int, ...] = (5, 10),
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not candidate_name:
        raise ValueError("candidate name must not be empty")
    if not top_ks or any(top_k <= 0 for top_k in top_ks):
        raise ValueError("top_ks must contain positive values")
    cases = load_jsonl(cases_path)
    if not cases:
        raise ValueError("benchmark cases must not be empty")
    max_k = max(top_ks)
    case_records: list[dict[str, Any]] = []
    latencies_ms: list[float] = []

    for case in cases:
        start = time.perf_counter_ns()
        results = retriever.retrieve(str(case["question"]), top_k=max_k)
        latency_ms = (time.perf_counter_ns() - start) / 1_000_000
        latencies_ms.append(latency_ms)
        retrieved_ids = [result.chunk.chunk_id for result in results]
        if len(retrieved_ids) != len(set(retrieved_ids)):
            raise ValueError(f"candidate returned duplicate chunks: {case['case_id']}")
        if [result.rank for result in results] != list(range(1, len(results) + 1)):
            raise ValueError(f"candidate returned invalid ranks: {case['case_id']}")
        metrics = {
            str(top_k): score_retrieval_case(
                retrieved_ids=retrieved_ids,
                accepted_evidence_groups=case["accepted_evidence_groups"],
                top_k=top_k,
            ).to_dict()
            for top_k in top_ks
        }
        case_records.append(
            {
                "case_id": case["case_id"],
                "category": case["category"],
                "difficulty": case["difficulty"],
                "retrieved_ids": retrieved_ids,
                "result_count": len(results),
                "latency_ms": latency_ms,
                "metrics": metrics,
            }
        )

    aggregate = {
        str(top_k): aggregate_retrieval_metrics(
            [
                {"category": record["category"], "metrics": record["metrics"][str(top_k)]}
                for record in case_records
            ]
        )
        for top_k in top_ks
    }
    return {
        "schema_version": 1,
        "candidate": candidate_name,
        "metadata": metadata or {},
        "cases_path": cases_path.as_posix(),
        "cases_sha256": sha256_file(cases_path),
        "chunks_path": chunks_path.as_posix(),
        "chunks_sha256": sha256_file(chunks_path),
        "case_count": len(case_records),
        "top_ks": list(top_ks),
        "latency_ms": {
            "p50": percentile(latencies_ms, 0.50),
            "p95": percentile(latencies_ms, 0.95),
            "minimum": min(latencies_ms),
            "maximum": max(latencies_ms),
        },
        "aggregate": aggregate,
        "cases": case_records,
    }


def save_benchmark_report(report: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
