"""Configuration helpers for the RAG MVP."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RAGConfig:
    """Runtime paths and simple defaults for the local RAG MVP."""

    project_root: Path
    raw_data_dir: Path
    processed_data_dir: Path
    index_path: Path
    chunks_path: Path
    eval_questions_path: Path
    eval_results_path: Path
    chunk_size: int = 500
    chunk_overlap: int = 100
    top_k: int = 5
    embedding_dim: int = 384

    @classmethod
    def from_project_root(cls, project_root: str | Path = ".") -> "RAGConfig":
        root = Path(project_root).resolve()
        return cls(
            project_root=root,
            raw_data_dir=root / "data" / "raw",
            processed_data_dir=root / "data" / "processed",
            index_path=root / "indexes" / "faiss.index",
            chunks_path=root / "indexes" / "chunks.jsonl",
            eval_questions_path=root / "eval" / "seed_questions.jsonl",
            eval_results_path=root / "eval" / "results.jsonl",
        )
