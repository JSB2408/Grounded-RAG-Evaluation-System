"""Optional LLM-as-judge evaluation for answer quality."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from typing import Protocol

from rag_mvp.schemas import Answer, EvaluationCase
from rag_mvp.vector_store import VectorSearchResult


@dataclass(frozen=True)
class QualityJudgment:
    """Structured quality judgment for one generated answer."""

    overall_passed: bool
    scores: dict[str, int] = field(default_factory=dict)
    issues: list[str] = field(default_factory=list)
    explanation: str = ""

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class AnswerQualityJudge(Protocol):
    """Judge interface for answer-quality evaluation."""

    def judge(
        self,
        case: EvaluationCase,
        answer: Answer,
        retrieved_results: list[VectorSearchResult],
    ) -> QualityJudgment:
        """Judge one answer against the question and retrieved context."""


class OpenAIAnswerQualityJudge:
    """OpenAI-backed direct-scoring judge for RAG answer quality."""

    def __init__(
        self,
        *,
        model: str = "gpt-4.1-mini",
        api_key: str | None = None,
        max_output_tokens: int = 700,
        temperature: float = 0.0,
        client: object | None = None,
    ) -> None:
        if not model:
            raise ValueError("model must not be empty")
        if max_output_tokens <= 0:
            raise ValueError("max_output_tokens must be positive")
        self.model = model
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        if client is not None:
            self._client = client
            return

        resolved_api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not resolved_api_key:
            raise ValueError("OPENAI_API_KEY must be set to use OpenAI quality judging")

        try:
            from openai import OpenAI
        except ImportError as error:
            raise RuntimeError(
                "openai package is required for OpenAI quality judging. "
                "Install project dependencies with `python -m pip install -e .`."
            ) from error

        self._client = OpenAI(api_key=resolved_api_key)

    def judge(
        self,
        case: EvaluationCase,
        answer: Answer,
        retrieved_results: list[VectorSearchResult],
    ) -> QualityJudgment:
        prompt = _build_judge_prompt(case, answer, retrieved_results)
        response = self._client.responses.create(
            model=self.model,
            input=prompt,
            max_output_tokens=self.max_output_tokens,
            temperature=self.temperature,
        )
        return _parse_judgment(_extract_response_text(response))


def create_quality_judge(
    provider: str,
    *,
    model: str | None = None,
) -> AnswerQualityJudge | None:
    """Create an optional answer-quality judge by name."""

    normalized_provider = provider.strip().lower()
    if normalized_provider == "none":
        return None
    if normalized_provider == "openai":
        return OpenAIAnswerQualityJudge(model=model or "gpt-4.1-mini")
    raise ValueError(f"unsupported quality judge provider: {provider}")


def _build_judge_prompt(
    case: EvaluationCase,
    answer: Answer,
    retrieved_results: list[VectorSearchResult],
) -> str:
    context = "\n\n".join(
        "\n".join(
            [
                f"[{result.chunk.chunk_id}]",
                f"Source: {result.chunk.source_path}",
                result.chunk.text,
            ]
        )
        for result in retrieved_results
    )
    expected = case.expected_answer or "(No reference answer provided.)"
    expected_behavior = (
        'The correct behavior is to output exactly "Insufficient evidence in the provided context."'
        if case.requires_insufficient_evidence
        else "The answer should address the question using the retrieved context and citations."
    )
    return f"""You are an independent evaluator for a citation-grounded RAG system.
Evaluate the answer only against the question, retrieved context, citations, and reference answer.
Do not reward verbosity. Penalize unsupported claims and imprecise citations.
If the expected behavior is an insufficient-evidence refusal and the answer exactly matches it, mark factual_correctness, completeness, and citation_precision as high.
Do not fail an answer for harmless examples, extra wording, or formatting differences if all required reference facts are present, grounded in the retrieved context, and not contradicted.

Score each criterion from 1 to 5:
- factual_correctness: claims match the retrieved context and reference answer.
- completeness: answer covers the expected answer without missing key points.
- citation_precision: cited chunks directly support the specific claims.
- conciseness: answer is brief and avoids unnecessary detail.

Return JSON only:
{{
  "overall_passed": true,
  "scores": {{
    "factual_correctness": 1,
    "completeness": 1,
    "citation_precision": 1,
    "conciseness": 1
  }},
  "issues": ["specific issue"],
  "explanation": "short evidence-based explanation"
}}

Question:
{case.question}

Reference answer:
{expected}

Expected behavior:
{expected_behavior}

Retrieved context:
{context}

Answer:
{answer.text}
"""


def _parse_judgment(response_text: str) -> QualityJudgment:
    payload = json.loads(_extract_json_text(response_text))
    scores = payload.get("scores", {})
    if not isinstance(scores, dict):
        scores = {}
    issues = payload.get("issues", [])
    if not isinstance(issues, list):
        issues = []
    return QualityJudgment(
        overall_passed=bool(payload.get("overall_passed", False)),
        scores={str(key): int(value) for key, value in scores.items()},
        issues=[str(issue) for issue in issues],
        explanation=str(payload.get("explanation", "")),
    )


def _extract_response_text(response: object) -> str:
    output_text = getattr(response, "output_text", None)
    if isinstance(output_text, str) and output_text.strip():
        return output_text.strip()
    raise RuntimeError("OpenAI judge response did not contain text output")


def _extract_json_text(text: str) -> str:
    compact = text.strip()
    if compact.startswith("```"):
        lines = compact.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        return "\n".join(lines).strip()
    return compact
