"""Application service for retrieval and grounded answer generation."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path

from rag_mvp.bm25 import BM25Retriever
from rag_mvp.config import RAGConfig
from rag_mvp.embeddings import create_embedding_provider
from rag_mvp.freeze_guard import sha256_file
from rag_mvp.generator import Generator, create_generator
from rag_mvp.indexing import build_index
from rag_mvp.retriever import RetrievalProtocol, Retriever
from rag_mvp.schemas import Answer, Chunk
from rag_mvp.vector_store import FaissVectorStore, VectorSearchResult


SUPPORTED_PROFILES = {"offline-demo", "portfolio", "semantic"}
SUPPORTED_RETRIEVAL_STRATEGIES = {"dense", "bm25"}


@dataclass(frozen=True)
class ServiceSettings:
    """Runtime configuration for the HTTP application."""

    project_root: Path
    profile: str = "offline-demo"
    embedding_provider: str = "local-hash"
    generator_provider: str = "template"
    retrieval_strategy: str = "dense"
    embedding_model: str | None = None
    generator_model: str | None = None
    embedding_dim: int = 384
    top_k: int = 5
    chunk_size: int = 500
    chunk_overlap: int = 100

    def __post_init__(self) -> None:
        if self.profile not in SUPPORTED_PROFILES:
            raise ValueError(f"unsupported RAG profile: {self.profile}")
        if self.retrieval_strategy not in SUPPORTED_RETRIEVAL_STRATEGIES:
            raise ValueError(f"unsupported retrieval strategy: {self.retrieval_strategy}")
        if self.profile == "portfolio" and self.retrieval_strategy != "bm25":
            raise ValueError("portfolio profile requires the frozen BM25 strategy")
        if self.profile != "portfolio" and self.retrieval_strategy != "dense":
            raise ValueError(f"{self.profile} profile requires dense retrieval")
        if self.embedding_dim <= 0:
            raise ValueError("embedding_dim must be positive")
        if self.top_k <= 0:
            raise ValueError("top_k must be positive")

    @classmethod
    def from_environment(cls) -> "ServiceSettings":
        """Resolve settings from environment variables with safe offline defaults."""

        project_root = Path(os.getenv("RAG_PROJECT_ROOT", ".")).resolve()
        profile = os.getenv("RAG_PROFILE", "portfolio").strip().lower()
        if profile not in SUPPORTED_PROFILES:
            raise ValueError(f"unsupported RAG profile: {profile}")

        semantic = profile == "semantic"
        portfolio = profile == "portfolio"
        return cls(
            project_root=project_root,
            profile=profile,
            embedding_provider=os.getenv(
                "RAG_EMBEDDING_PROVIDER",
                "openai" if semantic else "local-hash",
            ),
            generator_provider=os.getenv(
                "RAG_GENERATOR_PROVIDER",
                "openai" if semantic else "template",
            ),
            retrieval_strategy=os.getenv(
                "RAG_RETRIEVAL_STRATEGY", "bm25" if portfolio else "dense"
            ).strip().lower(),
            embedding_model=os.getenv("RAG_EMBEDDING_MODEL") or None,
            generator_model=os.getenv("RAG_GENERATOR_MODEL") or None,
            embedding_dim=_read_positive_int("RAG_EMBEDDING_DIM", 384),
            top_k=_read_positive_int("RAG_TOP_K", 5),
            chunk_size=_read_positive_int("RAG_CHUNK_SIZE", 500),
            chunk_overlap=_read_non_negative_int("RAG_CHUNK_OVERLAP", 100),
        )

    @property
    def index_path(self) -> Path:
        if self.profile == "offline-demo":
            return self.project_root / ".runtime" / "offline-demo" / "faiss.index"
        return self.project_root / "indexes" / "faiss.index"

    @property
    def chunks_path(self) -> Path:
        if self.profile == "portfolio":
            return self.project_root / "data" / "corpus-v1" / "chunks.jsonl"
        if self.profile == "offline-demo":
            return self.project_root / ".runtime" / "offline-demo" / "chunks.jsonl"
        return self.project_root / "indexes" / "chunks.jsonl"

    @property
    def selected_retrieval_path(self) -> Path:
        return self.project_root / "configs" / "selected-retrieval.json"


@dataclass(frozen=True)
class ServiceInfo:
    """Observable runtime metadata for readiness checks."""

    profile: str
    embedding_provider: str
    generator_provider: str
    retrieval_strategy: str
    selected_configuration: str | None
    index_dimension: int | None
    chunk_count: int


@dataclass(frozen=True)
class AnswerResult:
    """Generated answer together with the evidence returned by retrieval."""

    answer: Answer
    evidence: list[VectorSearchResult]


class RAGService:
    """Coordinate retrieval and generation for application callers."""

    def __init__(
        self,
        *,
        retriever: RetrievalProtocol,
        generator: Generator,
        settings: ServiceSettings,
        info: ServiceInfo,
    ) -> None:
        self._retriever = retriever
        self._generator = generator
        self.settings = settings
        self.info = info

    @classmethod
    def from_settings(cls, settings: ServiceSettings) -> "RAGService":
        if settings.profile == "portfolio":
            selected = json.loads(
                settings.selected_retrieval_path.read_text(encoding="utf-8")
            )
            if selected.get("selected_candidate") != "b1-bm25":
                raise ValueError("portfolio profile requires selected candidate b1-bm25")
            expected_chunks_hash = selected.get("artifact_bindings", {}).get(
                "chunks_sha256"
            )
            if not expected_chunks_hash or sha256_file(settings.chunks_path) != expected_chunks_hash:
                raise ValueError("portfolio chunks do not match the selected retrieval config")
            chunks = _load_chunks(settings.chunks_path)
            retriever = BM25Retriever(
                chunks,
                k1=float(selected["retriever"]["k1"]),
                b=float(selected["retriever"]["b"]),
            )
            return cls(
                retriever=retriever,
                generator=create_generator(
                    settings.generator_provider, model=settings.generator_model
                ),
                settings=settings,
                info=ServiceInfo(
                    profile=settings.profile,
                    embedding_provider="not-applicable",
                    generator_provider=settings.generator_provider,
                    retrieval_strategy="bm25",
                    selected_configuration=str(selected["selection_id"]),
                    index_dimension=None,
                    chunk_count=len(chunks),
                ),
            )

        config = RAGConfig.from_project_root(settings.project_root)
        embedding_provider = create_embedding_provider(
            settings.embedding_provider,
            model=settings.embedding_model,
            dimension=settings.embedding_dim,
        )

        if settings.profile == "offline-demo" and (
            not settings.index_path.exists() or not settings.chunks_path.exists()
        ):
            build_index(
                raw_data_dir=config.raw_data_dir,
                index_path=settings.index_path,
                chunks_path=settings.chunks_path,
                embedding_provider=embedding_provider,
                chunk_size=settings.chunk_size,
                chunk_overlap=settings.chunk_overlap,
            )

        store = FaissVectorStore.load(settings.index_path, settings.chunks_path)
        if settings.embedding_provider == "local-hash" and store.dimension != settings.embedding_dim:
            raise ValueError(
                f"local embedding dimension {settings.embedding_dim} does not match "
                f"index dimension {store.dimension}"
            )

        return cls(
            retriever=Retriever(embedding_provider, store),
            generator=create_generator(
                settings.generator_provider,
                model=settings.generator_model,
            ),
            settings=settings,
            info=ServiceInfo(
                profile=settings.profile,
                embedding_provider=settings.embedding_provider,
                generator_provider=settings.generator_provider,
                retrieval_strategy=settings.retrieval_strategy,
                selected_configuration=None,
                index_dimension=store.dimension,
                chunk_count=len(store.chunks),
            ),
        )

    def retrieve(self, question: str, *, top_k: int | None = None) -> list[VectorSearchResult]:
        return self._retriever.retrieve(question, top_k=top_k or self.settings.top_k)

    def answer(self, question: str, *, top_k: int | None = None) -> AnswerResult:
        evidence = self.retrieve(question, top_k=top_k)
        return AnswerResult(
            answer=self._generator.generate(question, evidence),
            evidence=evidence,
        )


def _read_positive_int(name: str, default: int) -> int:
    value = int(os.getenv(name, str(default)))
    if value <= 0:
        raise ValueError(f"{name} must be positive")
    return value


def _read_non_negative_int(name: str, default: int) -> int:
    value = int(os.getenv(name, str(default)))
    if value < 0:
        raise ValueError(f"{name} must be non-negative")
    return value


def _load_chunks(path: Path) -> list[Chunk]:
    chunks = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            chunks.append(Chunk(**json.loads(line)))
        except (TypeError, json.JSONDecodeError) as error:
            raise ValueError(f"invalid portfolio chunk at {path}:{line_number}") from error
    if not chunks:
        raise ValueError("portfolio chunks must not be empty")
    return chunks
