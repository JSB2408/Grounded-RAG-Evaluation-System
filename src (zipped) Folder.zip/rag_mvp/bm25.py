"""Deterministic BM25 lexical retrieval."""

from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Iterable

from rag_mvp.schemas import Chunk, RetrievalResult


TOKEN_PATTERN = re.compile(r"[A-Za-z0-9]+(?:[_-][A-Za-z0-9]+)*|[\u4e00-\u9fff]", re.UNICODE)


def tokenize(text: str) -> list[str]:
    """Tokenize English identifiers and CJK characters for lexical retrieval."""

    return [match.group(0).lower() for match in TOKEN_PATTERN.finditer(text)]


class BM25Retriever:
    """Okapi BM25 over a fixed chunk collection."""

    def __init__(self, chunks: Iterable[Chunk], *, k1: float = 1.5, b: float = 0.75) -> None:
        if k1 <= 0:
            raise ValueError("k1 must be positive")
        if not 0 <= b <= 1:
            raise ValueError("b must be between 0 and 1")
        self._chunks = list(chunks)
        if not self._chunks:
            raise ValueError("chunks must not be empty")
        if len({chunk.chunk_id for chunk in self._chunks}) != len(self._chunks):
            raise ValueError("chunk IDs must be unique")
        self.k1 = k1
        self.b = b
        self._term_frequencies = [Counter(tokenize(chunk.text)) for chunk in self._chunks]
        self._document_lengths = [sum(frequencies.values()) for frequencies in self._term_frequencies]
        if any(length == 0 for length in self._document_lengths):
            raise ValueError("chunks must contain at least one lexical token")
        self._average_document_length = sum(self._document_lengths) / len(self._document_lengths)
        document_frequencies: Counter[str] = Counter()
        for frequencies in self._term_frequencies:
            document_frequencies.update(frequencies.keys())
        total = len(self._chunks)
        self._idf = {
            term: math.log(1.0 + (total - frequency + 0.5) / (frequency + 0.5))
            for term, frequency in document_frequencies.items()
        }

    @property
    def chunks(self) -> list[Chunk]:
        return list(self._chunks)

    def retrieve(self, question: str, *, top_k: int = 5) -> list[RetrievalResult]:
        if not question.strip():
            raise ValueError("question must not be empty")
        if top_k <= 0:
            raise ValueError("top_k must be positive")
        query_terms = Counter(tokenize(question))
        if not query_terms:
            raise ValueError("question must contain at least one lexical token")
        scored: list[tuple[float, Chunk]] = []
        for chunk, frequencies, length in zip(
            self._chunks,
            self._term_frequencies,
            self._document_lengths,
            strict=True,
        ):
            score = 0.0
            length_normalizer = self.k1 * (
                1.0 - self.b + self.b * length / self._average_document_length
            )
            for term, query_frequency in query_terms.items():
                term_frequency = frequencies.get(term, 0)
                if term_frequency == 0:
                    continue
                score += (
                    self._idf[term]
                    * (term_frequency * (self.k1 + 1.0))
                    / (term_frequency + length_normalizer)
                    * query_frequency
                )
            if score > 0:
                scored.append((score, chunk))
        scored.sort(key=lambda item: (-item[0], item[1].chunk_id))
        return [
            RetrievalResult(chunk=chunk, score=score, rank=rank, strategy="bm25")
            for rank, (score, chunk) in enumerate(scored[:top_k], start=1)
        ]
