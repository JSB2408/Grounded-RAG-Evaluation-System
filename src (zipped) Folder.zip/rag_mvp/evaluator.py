"""Evaluation harness for retrieval, grounding, and answer quality."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from rag_mvp.answer_validation import validate_answer
from rag_mvp.citations import validate_citations
from rag_mvp.generator import INSUFFICIENT_EVIDENCE_MESSAGE, Generator
from rag_mvp.quality_judge import AnswerQualityJudge
from rag_mvp.retriever import RetrievalProtocol
from rag_mvp.schemas import EvaluationCase, EvaluationResult


def load_evaluation_cases(path: str | Path) -> list[EvaluationCase]:
    """Load JSONL evaluation cases."""

    cases_path = Path(path)
    if not cases_path.exists():
        raise FileNotFoundError(f"evaluation cases file does not exist: {cases_path}")

    cases: list[EvaluationCase] = []
    with cases_path.open("r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                cases.append(EvaluationCase(**json.loads(stripped)))
            except (TypeError, json.JSONDecodeError) as error:
                raise ValueError(
                    f"invalid evaluation case at {cases_path}:{line_number}"
                ) from error
    return cases


def save_evaluation_results(
    results: list[EvaluationResult],
    path: str | Path,
) -> None:
    """Write JSONL evaluation results."""

    results_path = Path(path)
    results_path.parent.mkdir(parents=True, exist_ok=True)
    with results_path.open("w", encoding="utf-8") as file:
        for result in results:
            file.write(json.dumps(asdict(result), ensure_ascii=False) + "\n")


class RAGEvaluator:
    """Run retrieval, generation, citation, and insufficient-evidence checks."""

    def __init__(
        self,
        retriever: RetrievalProtocol,
        generator: Generator,
        *,
        top_k: int = 5,
        quality_judge: AnswerQualityJudge | None = None,
    ) -> None:
        self._retriever = retriever
        self._generator = generator
        self._top_k = top_k
        self._quality_judge = quality_judge

    def evaluate(self, cases: list[EvaluationCase]) -> list[EvaluationResult]:
        return [self.evaluate_case(case) for case in cases]

    def evaluate_case(self, case: EvaluationCase) -> EvaluationResult:
        retrieved_results = self._retriever.retrieve(case.question, top_k=self._top_k)
        retrieved_chunks = [result.chunk.chunk_id for result in retrieved_results]
        answer = self._generator.generate(case.question, retrieved_results)
        citation_validation = validate_citations(
            answer.text,
            [result.chunk for result in retrieved_results],
        )
        answer_validation = validate_answer(
            answer,
            [result.chunk for result in retrieved_results],
        )
        expected_chunks = set(case.expected_chunks)
        recall_hit = expected_chunks.issubset(set(retrieved_chunks)) if expected_chunks else True

        insufficient_evidence_correct = None
        if case.requires_insufficient_evidence:
            insufficient_evidence_correct = answer.text.strip() == INSUFFICIENT_EVIDENCE_MESSAGE

        citation_supported = citation_validation.is_supported
        if insufficient_evidence_correct is True:
            citation_supported = True

        quality_judgment = None
        if self._quality_judge is not None and answer_validation.passed:
            quality_judgment = self._quality_judge.judge(
                case,
                answer,
                retrieved_results,
            ).to_dict()

        return EvaluationResult(
            question_id=case.question_id,
            question=case.question,
            expected_chunks=case.expected_chunks,
            retrieved_chunks=retrieved_chunks,
            recall_hit=recall_hit,
            answer=answer.text,
            citations=citation_validation.cited_chunk_ids,
            citation_supported=citation_supported,
            answer_validation_passed=answer_validation.passed,
            answer_validation_errors=answer_validation.errors,
            quality_judgment=quality_judgment,
            insufficient_evidence_correct=insufficient_evidence_correct,
            notes=case.notes,
        )
