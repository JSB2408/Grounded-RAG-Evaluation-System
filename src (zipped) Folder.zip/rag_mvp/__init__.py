"""Citation-grounded RAG MVP package."""
