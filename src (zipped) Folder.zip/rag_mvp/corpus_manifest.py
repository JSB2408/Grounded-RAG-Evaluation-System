"""Licensed corpus acquisition, validation, and source-traceable loading."""

from __future__ import annotations

import hashlib
import json
import shutil
import urllib.request
import zipfile
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

from rag_mvp.loaders import load_documents
from rag_mvp.schemas import Document
from rag_mvp.chunking import chunk_documents


ALLOWED_LICENSES = {"Apache-2.0", "MIT"}


def sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalize_text(content: bytes) -> str:
    text = content.decode("utf-8")
    normalized_newlines = text.replace("\r\n", "\n").replace("\r", "\n")
    normalized = "\n".join(line.rstrip() for line in normalized_newlines.split("\n"))
    return normalized.rstrip() + "\n"


def _load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return data


def _download_archive(url: str, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".part")
    with urllib.request.urlopen(url, timeout=180) as response, temporary.open("wb") as out:
        shutil.copyfileobj(response, out)
    temporary.replace(target)


def _archive_path(archive_dir: Path, source: dict[str, Any]) -> Path:
    revision = str(source["revision"]).replace("/", "-")
    return archive_dir / f"{source['source_id']}-{revision}.zip"


def _validate_source(source: dict[str, Any]) -> None:
    required = {
        "source_id",
        "name",
        "repository_url",
        "revision",
        "license_id",
        "license_url",
        "archive_url",
        "archive_sha256",
        "archive_root",
        "documents",
    }
    missing = required - source.keys()
    if missing:
        raise ValueError(f"source is missing fields: {sorted(missing)}")
    if source["license_id"] not in ALLOWED_LICENSES:
        raise ValueError(f"unsupported license: {source['license_id']}")
    documents = source["documents"]
    if not isinstance(documents, list) or not documents:
        raise ValueError(f"source {source['source_id']} has no documents")
    if len(documents) != len(set(documents)):
        raise ValueError(f"source {source['source_id']} has duplicate document paths")


def acquire_corpus(
    *,
    spec_path: Path,
    archive_dir: Path,
    raw_dir: Path,
    manifest_path: Path,
) -> dict[str, Any]:
    spec = _load_json(spec_path)
    if spec.get("schema_version") != 1:
        raise ValueError("unsupported corpus source spec schema")
    sources = spec.get("sources")
    if not isinstance(sources, list) or not sources:
        raise ValueError("corpus source spec has no sources")

    file_entries: list[dict[str, Any]] = []
    content_hashes: dict[str, str] = {}
    expected_outputs: set[str] = set()
    source_entries: list[dict[str, Any]] = []

    for raw_source in sources:
        if not isinstance(raw_source, dict):
            raise ValueError("source entries must be objects")
        source = dict(raw_source)
        _validate_source(source)
        archive_path = _archive_path(archive_dir, source)
        if not archive_path.exists():
            _download_archive(str(source["archive_url"]), archive_path)
        actual_archive_hash = sha256_file(archive_path)
        if actual_archive_hash != str(source["archive_sha256"]).lower():
            raise ValueError(f"archive hash mismatch for {source['source_id']}")

        source_file_entries: list[dict[str, Any]] = []
        with zipfile.ZipFile(archive_path) as archive:
            names = set(archive.namelist())
            for source_path in source["documents"]:
                archive_member = f"{source['archive_root']}/{source_path}"
                if archive_member not in names:
                    raise FileNotFoundError(
                        f"missing document {source_path!r} in {source['source_id']} archive"
                    )
                original = archive.read(archive_member)
                normalized = normalize_text(original).encode("utf-8")
                normalized_hash = sha256_bytes(normalized)
                duplicate = content_hashes.get(normalized_hash)
                if duplicate is not None:
                    raise ValueError(
                        f"duplicate normalized content: {source_path!r} matches {duplicate!r}"
                    )
                content_hashes[normalized_hash] = f"{source['source_id']}:{source_path}"

                corpus_path = Path(str(source["source_id"])) / Path(source_path)
                corpus_relative = corpus_path.as_posix()
                expected_outputs.add(corpus_relative)
                destination = raw_dir / corpus_path
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(normalized)
                document_id = f"{source['source_id']}-{hashlib.sha256(source_path.encode()).hexdigest()[:16]}"
                entry = {
                    "document_id": document_id,
                    "source_id": source["source_id"],
                    "source_path": source_path,
                    "corpus_path": corpus_relative,
                    "original_bytes": len(original),
                    "normalized_bytes": len(normalized),
                    "original_sha256": sha256_bytes(original),
                    "normalized_sha256": normalized_hash,
                }
                file_entries.append(entry)
                source_file_entries.append(entry)

        source_entries.append(
            {
                key: source[key]
                for key in (
                    "source_id",
                    "name",
                    "repository_url",
                    "revision",
                    "license_id",
                    "license_url",
                    "archive_url",
                    "archive_sha256",
                )
            }
            | {"document_count": len(source_file_entries)}
        )

    unexpected = sorted(
        path.relative_to(raw_dir).as_posix()
        for path in raw_dir.rglob("*")
        if path.is_file() and path.relative_to(raw_dir).as_posix() not in expected_outputs
    )
    if unexpected:
        raise ValueError(f"unexpected files already exist in corpus output: {unexpected}")

    manifest = {
        "schema_version": 1,
        "corpus_id": spec["corpus_id"],
        "acquired_at": spec["acquired_at"],
        "source_count": len(source_entries),
        "document_count": len(file_entries),
        "sources": source_entries,
        "documents": sorted(file_entries, key=lambda item: item["corpus_path"]),
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return manifest


def validate_corpus_manifest(raw_dir: Path, manifest_path: Path) -> dict[str, Any]:
    manifest = _load_json(manifest_path)
    documents = manifest.get("documents")
    if not isinstance(documents, list) or manifest.get("document_count") != len(documents):
        raise ValueError("corpus manifest document count mismatch")
    seen_ids: set[str] = set()
    seen_paths: set[str] = set()
    seen_hashes: set[str] = set()
    for entry in documents:
        document_id = str(entry["document_id"])
        corpus_path = str(entry["corpus_path"])
        normalized_hash = str(entry["normalized_sha256"])
        if document_id in seen_ids or corpus_path in seen_paths or normalized_hash in seen_hashes:
            raise ValueError("corpus manifest contains duplicate identity, path, or content")
        seen_ids.add(document_id)
        seen_paths.add(corpus_path)
        seen_hashes.add(normalized_hash)
        path = raw_dir / corpus_path
        if not path.is_file():
            raise FileNotFoundError(f"corpus document does not exist: {corpus_path}")
        if sha256_file(path) != normalized_hash:
            raise ValueError(f"corpus document hash mismatch: {corpus_path}")
        if path.stat().st_size != int(entry["normalized_bytes"]):
            raise ValueError(f"corpus document size mismatch: {corpus_path}")
    return manifest


def load_manifest_documents(raw_dir: Path, manifest_path: Path) -> list[Document]:
    manifest = validate_corpus_manifest(raw_dir, manifest_path)
    entries = {str(item["corpus_path"]): item for item in manifest["documents"]}
    documents = load_documents(raw_dir)
    if {document.source_path for document in documents} != set(entries):
        raise ValueError("loaded corpus paths do not match the manifest")
    loaded: list[Document] = []
    for document in documents:
        entry = entries[document.source_path]
        loaded.append(
            replace(
                document,
                source_id=str(entry["document_id"]),
                metadata={
                    **document.metadata,
                    "source_id": str(entry["source_id"]),
                    "upstream_path": str(entry["source_path"]),
                    "normalized_sha256": str(entry["normalized_sha256"]),
                },
            )
        )
    return loaded


def build_chunk_artifacts(
    *,
    raw_dir: Path,
    source_manifest_path: Path,
    chunks_path: Path,
    chunk_manifest_path: Path,
    chunk_size: int,
    chunk_overlap: int,
) -> dict[str, Any]:
    source_manifest = validate_corpus_manifest(raw_dir, source_manifest_path)
    documents = load_manifest_documents(raw_dir, source_manifest_path)
    chunks = chunk_documents(
        documents,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    if not chunks:
        raise ValueError("corpus produced no chunks")
    chunk_ids = [chunk.chunk_id for chunk in chunks]
    if len(chunk_ids) != len(set(chunk_ids)):
        raise ValueError("chunk IDs are not unique")
    document_ids = {str(item["document_id"]) for item in source_manifest["documents"]}
    if {chunk.source_id for chunk in chunks} != document_ids:
        raise ValueError("not every manifest document produced a chunk")

    chunks_path.parent.mkdir(parents=True, exist_ok=True)
    with chunks_path.open("w", encoding="utf-8", newline="\n") as output:
        for chunk in chunks:
            output.write(json.dumps(asdict(chunk), ensure_ascii=False, sort_keys=True) + "\n")

    chunk_manifest = {
        "schema_version": 1,
        "corpus_id": source_manifest["corpus_id"],
        "source_manifest_sha256": sha256_file(source_manifest_path),
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "document_count": len(documents),
        "chunk_count": len(chunks),
        "chunks_sha256": sha256_file(chunks_path),
    }
    chunk_manifest_path.parent.mkdir(parents=True, exist_ok=True)
    chunk_manifest_path.write_text(
        json.dumps(chunk_manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return chunk_manifest


def validate_chunk_artifacts(
    *,
    raw_dir: Path,
    source_manifest_path: Path,
    chunks_path: Path,
    chunk_manifest_path: Path,
) -> dict[str, Any]:
    source_manifest = validate_corpus_manifest(raw_dir, source_manifest_path)
    chunk_manifest = _load_json(chunk_manifest_path)
    if chunk_manifest.get("source_manifest_sha256") != sha256_file(source_manifest_path):
        raise ValueError("source manifest hash mismatch in chunk manifest")
    if chunk_manifest.get("chunks_sha256") != sha256_file(chunks_path):
        raise ValueError("chunks file hash mismatch")
    records = [
        json.loads(line)
        for line in chunks_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if chunk_manifest.get("chunk_count") != len(records):
        raise ValueError("chunk count mismatch")
    if chunk_manifest.get("document_count") != source_manifest.get("document_count"):
        raise ValueError("chunk manifest document count mismatch")
    chunk_ids = [str(record["chunk_id"]) for record in records]
    if len(chunk_ids) != len(set(chunk_ids)):
        raise ValueError("duplicate chunk IDs")
    document_ids = {str(item["document_id"]) for item in source_manifest["documents"]}
    if {str(record["source_id"]) for record in records} != document_ids:
        raise ValueError("chunk source coverage does not match corpus documents")
    for record in records:
        if not str(record["text"]).strip():
            raise ValueError("empty chunk text")
        metadata = record.get("metadata")
        if not isinstance(metadata, dict) or not {
            "source_id",
            "upstream_path",
            "normalized_sha256",
        }.issubset(metadata):
            raise ValueError("chunk is missing source-traceability metadata")
    return chunk_manifest


def document_tree_sha256(source_manifest: dict[str, Any]) -> str:
    digest = hashlib.sha256()
    for entry in sorted(source_manifest["documents"], key=lambda item: item["corpus_path"]):
        digest.update(str(entry["corpus_path"]).encode("utf-8"))
        digest.update(b"\0")
        digest.update(str(entry["normalized_sha256"]).encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def build_corpus_freeze_manifest(
    *,
    spec_path: Path,
    raw_dir: Path,
    source_manifest_path: Path,
    chunks_path: Path,
    chunk_manifest_path: Path,
    freeze_manifest_path: Path,
) -> dict[str, Any]:
    spec = _load_json(spec_path)
    source_manifest = validate_corpus_manifest(raw_dir, source_manifest_path)
    chunk_manifest = validate_chunk_artifacts(
        raw_dir=raw_dir,
        source_manifest_path=source_manifest_path,
        chunks_path=chunks_path,
        chunk_manifest_path=chunk_manifest_path,
    )
    freeze_manifest = {
        "schema_version": 1,
        "freeze_id": "corpus-v1-r2",
        "frozen_at": source_manifest["acquired_at"],
        "corpus_id": source_manifest["corpus_id"],
        "source_count": source_manifest["source_count"],
        "document_count": source_manifest["document_count"],
        "chunk_count": chunk_manifest["chunk_count"],
        "chunk_size": chunk_manifest["chunk_size"],
        "chunk_overlap": chunk_manifest["chunk_overlap"],
        "document_tree_sha256": document_tree_sha256(source_manifest),
        "files": {
            "source_spec": {
                "path": spec_path.as_posix(),
                "sha256": sha256_file(spec_path),
            },
            "source_manifest": {
                "path": source_manifest_path.as_posix(),
                "sha256": sha256_file(source_manifest_path),
            },
            "chunk_manifest": {
                "path": chunk_manifest_path.as_posix(),
                "sha256": sha256_file(chunk_manifest_path),
            },
            "chunks": {
                "path": chunks_path.as_posix(),
                "sha256": sha256_file(chunks_path),
            },
        },
        "construction_policy": (
            "Selected only from pinned official documentation before development and "
            "frozen-test case authoring; no evaluation labels are corpus inputs."
        ),
        "source_spec_corpus_id": spec["corpus_id"],
    }
    freeze_manifest_path.parent.mkdir(parents=True, exist_ok=True)
    freeze_manifest_path.write_text(
        json.dumps(freeze_manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return freeze_manifest


def validate_corpus_freeze_manifest(
    *,
    raw_dir: Path,
    freeze_manifest_path: Path,
) -> dict[str, Any]:
    freeze = _load_json(freeze_manifest_path)
    if freeze.get("freeze_id") != "corpus-v1-r2":
        raise ValueError("unexpected corpus freeze ID")
    files = freeze.get("files")
    if not isinstance(files, dict):
        raise ValueError("corpus freeze has no files")
    resolved: dict[str, Path] = {}
    for name in ("source_spec", "source_manifest", "chunk_manifest", "chunks"):
        entry = files.get(name)
        if not isinstance(entry, dict):
            raise ValueError(f"corpus freeze is missing {name}")
        path = Path(str(entry["path"]))
        if not path.is_file():
            raise FileNotFoundError(f"frozen file does not exist: {path}")
        if sha256_file(path) != str(entry["sha256"]):
            raise ValueError(f"frozen file hash mismatch: {name}")
        resolved[name] = path
    source_manifest = validate_corpus_manifest(raw_dir, resolved["source_manifest"])
    chunk_manifest = validate_chunk_artifacts(
        raw_dir=raw_dir,
        source_manifest_path=resolved["source_manifest"],
        chunks_path=resolved["chunks"],
        chunk_manifest_path=resolved["chunk_manifest"],
    )
    if freeze.get("document_tree_sha256") != document_tree_sha256(source_manifest):
        raise ValueError("frozen document tree hash mismatch")
    if freeze.get("document_count") != source_manifest.get("document_count"):
        raise ValueError("frozen document count mismatch")
    if freeze.get("chunk_count") != chunk_manifest.get("chunk_count"):
        raise ValueError("frozen chunk count mismatch")
    return freeze
