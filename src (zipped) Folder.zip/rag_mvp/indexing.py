"""Reusable document-ingestion pipeline."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from rag_mvp.chunking import chunk_documents
from rag_mvp.embeddings import EmbeddingProvider
from rag_mvp.loaders import load_documents
from rag_mvp.vector_store import FaissVectorStore


@dataclass(frozen=True)
class IngestionSummary:
    """Counts and paths produced by one ingestion run."""

    document_count: int
    chunk_count: int
    index_path: Path
    chunks_path: Path


def build_index(
    *,
    raw_data_dir: str | Path,
    index_path: str | Path,
    chunks_path: str | Path,
    embedding_provider: EmbeddingProvider,
    chunk_size: int,
    chunk_overlap: int,
) -> IngestionSummary:
    """Load documents, create chunks, and persist their FAISS index."""

    documents = load_documents(raw_data_dir)
    chunks = chunk_documents(
        documents,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    if not chunks:
        raise ValueError(f"no chunks produced from supported documents in {raw_data_dir}")

    embeddings = embedding_provider.embed_texts([chunk.text for chunk in chunks])
    store = FaissVectorStore.from_embeddings(chunks, embeddings)
    store.save(index_path, chunks_path)
    return IngestionSummary(
        document_count=len(documents),
        chunk_count=len(chunks),
        index_path=Path(index_path),
        chunks_path=Path(chunks_path),
    )
