"""Post-generation validation for grounded answers."""

from __future__ import annotations

from dataclasses import dataclass, field
from collections.abc import Iterable

from rag_mvp.generator import INSUFFICIENT_EVIDENCE_MESSAGE
from rag_mvp.schemas import Answer, Chunk


@dataclass(frozen=True)
class AnswerValidation:
    """Deterministic validation result for a generated answer."""

    passed: bool
    errors: list[str] = field(default_factory=list)


def validate_answer(
    answer: Answer,
    available_chunks: Iterable[Chunk],
    *,
    max_claims: int = 3,
    max_citations_per_claim: int = 2,
) -> AnswerValidation:
    """Validate answer structure before semantic judging."""

    errors: list[str] = []
    available_ids = {chunk.chunk_id for chunk in available_chunks}

    if answer.text.strip() == INSUFFICIENT_EVIDENCE_MESSAGE:
        if answer.claims:
            errors.append("insufficient-evidence refusal must not contain claims")
        if answer.citations:
            errors.append("insufficient-evidence refusal must not contain citations")
        return AnswerValidation(passed=not errors, errors=errors)

    if not answer.claims:
        errors.append("answered responses must include structured claims")
    if len(answer.claims) > max_claims:
        errors.append(f"answer has more than {max_claims} claims")

    for index, claim in enumerate(answer.claims, start=1):
        if not claim.citations:
            errors.append(f"claim {index} has no citation")
            continue
        if len(claim.citations) > max_citations_per_claim:
            errors.append(f"claim {index} has more than {max_citations_per_claim} citations")
        missing_ids = [citation for citation in claim.citations if citation not in available_ids]
        if missing_ids:
            errors.append(f"claim {index} cites unavailable chunks: {', '.join(missing_ids)}")

    return AnswerValidation(passed=not errors, errors=errors)
