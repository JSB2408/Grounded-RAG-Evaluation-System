"""Vector index wrapper for FAISS-backed similarity search."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Self

import faiss
import numpy as np

from rag_mvp.embeddings import normalize_matrix, normalize_vector
from rag_mvp.schemas import Chunk, RetrievalResult


VectorSearchResult = RetrievalResult


class FaissVectorStore:
    """FAISS-backed cosine-similarity search over chunk embeddings."""

    def __init__(self, index: faiss.Index, chunks: list[Chunk]) -> None:
        if index.ntotal != len(chunks):
            raise ValueError("FAISS index size must match chunk count")
        self._index = index
        self._chunks = list(chunks)

    @classmethod
    def from_embeddings(
        cls,
        chunks: list[Chunk],
        embeddings: np.ndarray,
    ) -> Self:
        """Build a vector store from chunks and their embeddings."""

        if not chunks:
            raise ValueError("chunks must not be empty")
        if len(chunks) != len(embeddings):
            raise ValueError("chunk count must match embedding count")

        normalized = normalize_matrix(embeddings)
        dimension = normalized.shape[1]
        index = faiss.IndexFlatIP(dimension)
        index.add(normalized)
        return cls(index=index, chunks=chunks)

    @property
    def dimension(self) -> int:
        return self._index.d

    @property
    def chunks(self) -> list[Chunk]:
        return list(self._chunks)

    def search(self, query_embedding: np.ndarray, *, top_k: int) -> list[VectorSearchResult]:
        """Search for the top-k most similar chunks."""

        if top_k <= 0:
            raise ValueError("top_k must be positive")
        normalized_query = normalize_vector(query_embedding)
        if normalized_query.shape[0] != self.dimension:
            raise ValueError(
                f"query embedding dimension {normalized_query.shape[0]} "
                f"does not match index dimension {self.dimension}"
            )

        scores, indices = self._index.search(normalized_query.reshape(1, -1), top_k)
        results: list[VectorSearchResult] = []
        for rank, (score, index) in enumerate(zip(scores[0], indices[0]), start=1):
            if index < 0:
                continue
            results.append(
                VectorSearchResult(
                    chunk=self._chunks[int(index)],
                    score=float(score),
                    rank=rank,
                )
            )
        return results

    def save(self, index_path: str | Path, chunks_path: str | Path) -> None:
        """Persist the FAISS index and chunk metadata."""

        index_file = Path(index_path)
        chunks_file = Path(chunks_path)
        index_file.parent.mkdir(parents=True, exist_ok=True)
        chunks_file.parent.mkdir(parents=True, exist_ok=True)

        serialized_index = faiss.serialize_index(self._index)
        index_file.write_bytes(bytes(serialized_index))
        with chunks_file.open("w", encoding="utf-8") as file:
            for chunk in self._chunks:
                file.write(json.dumps(asdict(chunk), ensure_ascii=False) + "\n")

    @classmethod
    def load(cls, index_path: str | Path, chunks_path: str | Path) -> Self:
        """Load a persisted FAISS index and chunk metadata."""

        index_file = Path(index_path)
        chunks_file = Path(chunks_path)
        if not index_file.exists():
            raise FileNotFoundError(f"FAISS index file does not exist: {index_file}")
        if not chunks_file.exists():
            raise FileNotFoundError(f"chunks file does not exist: {chunks_file}")

        index_bytes = np.frombuffer(index_file.read_bytes(), dtype=np.uint8)
        index = faiss.deserialize_index(index_bytes)
        chunks: list[Chunk] = []
        with chunks_file.open("r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    chunks.append(Chunk(**json.loads(stripped)))
                except (TypeError, json.JSONDecodeError) as error:
                    raise ValueError(
                        f"invalid chunk metadata at {chunks_file}:{line_number}"
                    ) from error

        return cls(index=index, chunks=chunks)
