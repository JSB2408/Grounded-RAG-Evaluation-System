"""Citation parsing and validation helpers."""

from __future__ import annotations

import re
from dataclasses import dataclass
from collections.abc import Iterable

from rag_mvp.schemas import Chunk


_CITATION_PATTERN = re.compile(r"\[([A-Za-z0-9_.-]+_chunk_\d{4})\]")


@dataclass(frozen=True)
class CitationValidation:
    """Citation validation result."""

    cited_chunk_ids: list[str]
    missing_chunk_ids: list[str]

    @property
    def is_supported(self) -> bool:
        return bool(self.cited_chunk_ids) and not self.missing_chunk_ids


def extract_citations(answer_text: str) -> list[str]:
    """Extract chunk citations from answer text."""

    citations = _CITATION_PATTERN.findall(answer_text)
    return list(dict.fromkeys(citations))


def validate_citations(
    answer_text: str,
    available_chunks: Iterable[Chunk],
) -> CitationValidation:
    """Check that every cited chunk exists in the retrieved context."""

    cited_ids = extract_citations(answer_text)
    available_ids = {chunk.chunk_id for chunk in available_chunks}
    missing_ids = [chunk_id for chunk_id in cited_ids if chunk_id not in available_ids]
    return CitationValidation(cited_chunk_ids=cited_ids, missing_chunk_ids=missing_ids)
