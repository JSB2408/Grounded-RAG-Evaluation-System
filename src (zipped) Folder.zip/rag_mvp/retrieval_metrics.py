"""Rank-aware retrieval metrics over accepted evidence groups."""

from __future__ import annotations

import math
import random
from dataclasses import asdict, dataclass
from statistics import mean
from typing import Any


@dataclass(frozen=True)
class RetrievalCaseMetrics:
    all_evidence_recall: float | None
    partial_evidence_recall: float | None
    reciprocal_rank: float | None
    ndcg: float | None
    zero_hit: bool | None

    def to_dict(self) -> dict[str, float | bool | None]:
        return asdict(self)


def score_retrieval_case(
    *,
    retrieved_ids: list[str],
    accepted_evidence_groups: list[list[str]],
    top_k: int,
) -> RetrievalCaseMetrics:
    if top_k <= 0:
        raise ValueError("top_k must be positive")
    if len(retrieved_ids) != len(set(retrieved_ids)):
        raise ValueError("retrieved IDs must be unique")
    if not accepted_evidence_groups:
        return RetrievalCaseMetrics(None, None, None, None, None)
    if any(not group for group in accepted_evidence_groups):
        raise ValueError("accepted evidence groups must not be empty")
    ranked = retrieved_ids[:top_k]
    ranks = {chunk_id: rank for rank, chunk_id in enumerate(ranked, start=1)}
    group_ranks = [
        min((ranks[item] for item in group if item in ranks), default=None)
        for group in accepted_evidence_groups
    ]
    hit_count = sum(rank is not None for rank in group_ranks)
    all_recall = float(hit_count == len(accepted_evidence_groups))
    partial_recall = hit_count / len(accepted_evidence_groups)
    first_rank = min((rank for rank in group_ranks if rank is not None), default=None)
    reciprocal_rank = 0.0 if first_rank is None else 1.0 / first_rank
    dcg = sum(
        1.0 / math.log2(rank + 1) for rank in group_ranks if rank is not None
    )
    ideal_hits = min(len(accepted_evidence_groups), top_k)
    ideal_dcg = sum(1.0 / math.log2(rank + 1) for rank in range(1, ideal_hits + 1))
    return RetrievalCaseMetrics(
        all_evidence_recall=all_recall,
        partial_evidence_recall=partial_recall,
        reciprocal_rank=reciprocal_rank,
        ndcg=dcg / ideal_dcg if ideal_dcg else 0.0,
        zero_hit=hit_count == 0,
    )


def aggregate_retrieval_metrics(records: list[dict[str, Any]]) -> dict[str, Any]:
    scored = [record for record in records if record["metrics"]["all_evidence_recall"] is not None]
    if not scored:
        raise ValueError("no answerable retrieval cases to aggregate")

    def average(name: str) -> float:
        return mean(float(record["metrics"][name]) for record in scored)

    categories: dict[str, dict[str, float | int]] = {}
    for category in sorted({str(record["category"]) for record in scored}):
        members = [record for record in scored if record["category"] == category]
        categories[category] = {
            "count": len(members),
            "all_evidence_recall": mean(
                float(record["metrics"]["all_evidence_recall"]) for record in members
            ),
            "partial_evidence_recall": mean(
                float(record["metrics"]["partial_evidence_recall"]) for record in members
            ),
            "mrr": mean(float(record["metrics"]["reciprocal_rank"]) for record in members),
            "ndcg": mean(float(record["metrics"]["ndcg"]) for record in members),
            "zero_hit_rate": mean(float(record["metrics"]["zero_hit"]) for record in members),
        }
    return {
        "answerable_count": len(scored),
        "all_evidence_recall": average("all_evidence_recall"),
        "partial_evidence_recall": average("partial_evidence_recall"),
        "mrr": average("reciprocal_rank"),
        "ndcg": average("ndcg"),
        "zero_hit_rate": average("zero_hit"),
        "categories": categories,
    }


def paired_bootstrap_delta(
    baseline: list[float],
    candidate: list[float],
    *,
    samples: int = 10_000,
    seed: int = 20260902,
) -> dict[str, float | int]:
    """Estimate a paired mean delta and percentile confidence interval."""
    if len(baseline) != len(candidate) or not baseline:
        raise ValueError("paired samples must be non-empty and equal in length")
    if samples <= 0:
        raise ValueError("samples must be positive")
    deltas = [right - left for left, right in zip(baseline, candidate, strict=True)]
    rng = random.Random(seed)
    bootstrapped = sorted(
        mean(deltas[rng.randrange(len(deltas))] for _ in deltas)
        for _ in range(samples)
    )

    def percentile_index(probability: float) -> int:
        return min(samples - 1, max(0, round(probability * (samples - 1))))

    return {
        "paired_count": len(deltas),
        "samples": samples,
        "seed": seed,
        "mean_delta": mean(deltas),
        "ci95_low": bootstrapped[percentile_index(0.025)],
        "ci95_high": bootstrapped[percentile_index(0.975)],
    }
