"""Command-line interface for ingestion, answering, and evaluation."""

from __future__ import annotations

import argparse
from pathlib import Path

from rag_mvp.config import RAGConfig
from rag_mvp.embeddings import create_embedding_provider
from rag_mvp.evaluator import RAGEvaluator, load_evaluation_cases, save_evaluation_results
from rag_mvp.generator import create_generator
from rag_mvp.indexing import build_index
from rag_mvp.prompt_builder import build_prompt
from rag_mvp.quality_judge import create_quality_judge
from rag_mvp.retriever import Retriever
from rag_mvp.vector_store import FaissVectorStore


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()
    config = RAGConfig.from_project_root(args.project_root)

    if args.command == "ingest":
        _run_ingest(args, config)
    elif args.command == "ask":
        _run_ask(args, config)
    elif args.command == "evaluate":
        _run_evaluate(args, config)
    else:
        parser.print_help()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="rag")
    parser.add_argument("--project-root", default=".", help="Project root path.")
    subparsers = parser.add_subparsers(dest="command")

    ingest = subparsers.add_parser("ingest", help="Load documents and build FAISS index.")
    ingest.add_argument("--raw-dir", type=Path, default=None)
    ingest.add_argument("--chunk-size", type=int, default=None)
    ingest.add_argument("--chunk-overlap", type=int, default=None)
    ingest.add_argument("--embedding-dim", type=int, default=None)
    ingest.add_argument("--embedding-provider", choices=["local-hash", "openai"], default="local-hash")
    ingest.add_argument("--embedding-model", default=None)

    ask = subparsers.add_parser("ask", help="Ask a question against the local index.")
    ask.add_argument("question")
    ask.add_argument("--top-k", type=int, default=None)
    ask.add_argument("--embedding-dim", type=int, default=None)
    ask.add_argument("--embedding-provider", choices=["local-hash", "openai"], default="local-hash")
    ask.add_argument("--embedding-model", default=None)
    ask.add_argument("--generator-provider", choices=["template", "openai"], default="template")
    ask.add_argument("--generator-model", default=None)
    ask.add_argument("--show-prompt", action="store_true")

    evaluate = subparsers.add_parser("evaluate", help="Run seed evaluation questions.")
    evaluate.add_argument("--questions", type=Path, default=None)
    evaluate.add_argument("--results", type=Path, default=None)
    evaluate.add_argument("--top-k", type=int, default=None)
    evaluate.add_argument("--embedding-dim", type=int, default=None)
    evaluate.add_argument("--embedding-provider", choices=["local-hash", "openai"], default="local-hash")
    evaluate.add_argument("--embedding-model", default=None)
    evaluate.add_argument("--generator-provider", choices=["template", "openai"], default="template")
    evaluate.add_argument("--generator-model", default=None)
    evaluate.add_argument("--quality-judge-provider", choices=["none", "openai"], default="none")
    evaluate.add_argument("--quality-judge-model", default=None)

    return parser


def _run_ingest(args: argparse.Namespace, config: RAGConfig) -> None:
    raw_dir = args.raw_dir or config.raw_data_dir
    chunk_size = args.chunk_size or config.chunk_size
    chunk_overlap = args.chunk_overlap if args.chunk_overlap is not None else config.chunk_overlap
    embedding_dim = args.embedding_dim or config.embedding_dim

    embedding_provider = create_embedding_provider(
        args.embedding_provider,
        model=args.embedding_model,
        dimension=embedding_dim,
    )
    try:
        summary = build_index(
            raw_data_dir=raw_dir,
            index_path=config.index_path,
            chunks_path=config.chunks_path,
            embedding_provider=embedding_provider,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
    except ValueError as error:
        raise SystemExit(str(error)) from error

    print(f"Loaded documents: {summary.document_count}")
    print(f"Created chunks: {summary.chunk_count}")
    print(f"Saved index: {summary.index_path}")
    print(f"Saved chunks: {summary.chunks_path}")


def _run_ask(args: argparse.Namespace, config: RAGConfig) -> None:
    top_k = args.top_k or config.top_k
    embedding_dim = args.embedding_dim or config.embedding_dim
    retriever = _build_retriever(
        config,
        embedding_dim=embedding_dim,
        embedding_provider_name=args.embedding_provider,
        embedding_model=args.embedding_model,
    )
    retrieved_results = retriever.retrieve(args.question, top_k=top_k)

    if args.show_prompt:
        print(build_prompt(args.question, retrieved_results))
        print()

    generator = create_generator(args.generator_provider, model=args.generator_model)
    answer = generator.generate(args.question, retrieved_results)
    print(answer.text)
    if answer.citations:
        print()
        print("Citations: " + ", ".join(answer.citations))
    print("Retrieved chunks: " + ", ".join(answer.retrieved_chunks))


def _run_evaluate(args: argparse.Namespace, config: RAGConfig) -> None:
    questions_path = args.questions or config.eval_questions_path
    results_path = args.results or config.eval_results_path
    top_k = args.top_k or config.top_k
    embedding_dim = args.embedding_dim or config.embedding_dim

    cases = load_evaluation_cases(questions_path)
    retriever = _build_retriever(
        config,
        embedding_dim=embedding_dim,
        embedding_provider_name=args.embedding_provider,
        embedding_model=args.embedding_model,
    )
    evaluator = RAGEvaluator(
        retriever,
        create_generator(args.generator_provider, model=args.generator_model),
        top_k=top_k,
        quality_judge=create_quality_judge(
            args.quality_judge_provider,
            model=args.quality_judge_model,
        ),
    )
    results = evaluator.evaluate(cases)
    save_evaluation_results(results, results_path)

    if not results:
        print("Evaluated cases: 0")
        print(f"Saved results: {results_path}")
        return

    recall_hits = sum(1 for result in results if result.recall_hit)
    citation_hits = sum(1 for result in results if result.citation_supported)
    validation_hits = sum(1 for result in results if result.answer_validation_passed)
    judged_results = [result for result in results if result.quality_judgment is not None]
    print(f"Evaluated cases: {len(results)}")
    print(f"Recall hits: {recall_hits}/{len(results)}")
    print(f"Citation-supported answers: {citation_hits}/{len(results)}")
    print(f"Answer validation passed: {validation_hits}/{len(results)}")
    if judged_results:
        judge_hits = sum(
            1 for result in judged_results if result.quality_judgment and result.quality_judgment.get("overall_passed")
        )
        print(f"Quality-judge passed: {judge_hits}/{len(judged_results)}")
    print(f"Saved results: {results_path}")


def _build_retriever(
    config: RAGConfig,
    *,
    embedding_dim: int,
    embedding_provider_name: str,
    embedding_model: str | None,
) -> Retriever:
    store = FaissVectorStore.load(config.index_path, config.chunks_path)
    embedding_provider = create_embedding_provider(
        embedding_provider_name,
        model=embedding_model,
        dimension=embedding_dim,
    )
    return Retriever(embedding_provider, store)
