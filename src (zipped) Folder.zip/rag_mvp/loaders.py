"""Document loading for markdown and plain-text files."""

from __future__ import annotations

import re
from pathlib import Path

from rag_mvp.schemas import Document


SUPPORTED_EXTENSIONS = {".md", ".txt"}


def load_documents(root_dir: str | Path) -> list[Document]:
    """Load supported documents from a directory in deterministic order."""

    root = Path(root_dir)
    if not root.exists():
        raise FileNotFoundError(f"document root does not exist: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"document root is not a directory: {root}")

    documents: list[Document] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue

        text = path.read_text(encoding="utf-8")
        relative_path = path.relative_to(root).as_posix()
        documents.append(
            Document(
                source_id=_source_id_from_relative_path(relative_path),
                source_path=relative_path,
                title=_extract_title(text, path.suffix.lower()),
                text=text,
                metadata={"extension": path.suffix.lower()},
            )
        )

    return documents


def _source_id_from_relative_path(relative_path: str) -> str:
    source_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", relative_path)
    return source_id.strip("_")


def _extract_title(text: str, suffix: str) -> str | None:
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if suffix == ".md":
            markdown_heading = re.match(r"^#{1,6}\s+(.+)$", stripped)
            if markdown_heading:
                return markdown_heading.group(1).strip()
        return stripped[:120]
    return None
