"""Retrieval pipeline from user question to top-k chunks."""

from __future__ import annotations

from typing import Protocol

from rag_mvp.embeddings import EmbeddingProvider
from rag_mvp.schemas import RetrievalResult
from rag_mvp.vector_store import FaissVectorStore, VectorSearchResult


class RetrievalProtocol(Protocol):
    """Common query-to-ranked-evidence interface."""

    def retrieve(self, question: str, *, top_k: int = 5) -> list[RetrievalResult]:
        """Return deterministic top-k evidence for a non-empty question."""


class Retriever:
    """Retrieve top-k chunks for a user question."""

    def __init__(
        self,
        embedding_provider: EmbeddingProvider,
        vector_store: FaissVectorStore,
    ) -> None:
        self._embedding_provider = embedding_provider
        self._vector_store = vector_store

    def retrieve(self, question: str, *, top_k: int = 5) -> list[RetrievalResult]:
        if not question.strip():
            raise ValueError("question must not be empty")
        query_embedding = self._embedding_provider.embed_query(question)
        return self._vector_store.search(query_embedding, top_k=top_k)
