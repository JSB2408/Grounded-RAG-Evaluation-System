"""Pinned local cross-encoder reranking."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from rag_mvp.retriever import RetrievalProtocol
from rag_mvp.schemas import RetrievalResult


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_model_manifest(manifest_path: Path, *, project_root: Path | None = None) -> dict[str, Any]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1:
        raise ValueError("unsupported reranker model manifest")
    root = project_root or Path.cwd()
    model_dir = Path(str(manifest["model_dir"]))
    if not model_dir.is_absolute():
        model_dir = root / model_dir
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise ValueError("reranker model manifest has no files")
    expected_paths: set[str] = set()
    for entry in files:
        relative = str(entry["path"])
        expected_paths.add(relative)
        path = model_dir / relative
        if not path.is_file():
            raise FileNotFoundError(f"reranker file is missing: {relative}")
        if path.stat().st_size != int(entry["bytes"]):
            raise ValueError(f"reranker file size mismatch: {relative}")
        if sha256_file(path) != str(entry["sha256"]):
            raise ValueError(f"reranker file hash mismatch: {relative}")
    actual_paths = {
        path.relative_to(model_dir).as_posix() for path in model_dir.rglob("*") if path.is_file()
    }
    if actual_paths != expected_paths:
        raise ValueError("reranker model directory differs from the manifest")
    manifest["resolved_model_dir"] = str(model_dir.resolve())
    return manifest


class CrossEncoderReranker:
    """Rerank query-passage pairs with a pinned local CrossEncoder."""

    def __init__(
        self,
        *,
        model: object | None = None,
        model_dir: Path | None = None,
        device: str = "cpu",
        max_length: int = 512,
        batch_size: int = 16,
    ) -> None:
        if max_length <= 0 or batch_size <= 0:
            raise ValueError("max_length and batch_size must be positive")
        self.max_length = max_length
        self.batch_size = batch_size
        self.device = device
        if model is not None:
            self._model = model
            return
        if model_dir is None or not model_dir.is_dir():
            raise ValueError("model_dir must be an existing directory")
        from sentence_transformers import CrossEncoder

        self._model = CrossEncoder(
            str(model_dir),
            device=device,
            max_length=max_length,
            local_files_only=True,
            trust_remote_code=False,
        )

    def rerank(
        self,
        question: str,
        candidates: Sequence[RetrievalResult],
        *,
        top_k: int,
    ) -> list[RetrievalResult]:
        if not question.strip():
            raise ValueError("question must not be empty")
        if top_k <= 0:
            raise ValueError("top_k must be positive")
        if not candidates:
            return []
        chunk_ids = [candidate.chunk.chunk_id for candidate in candidates]
        if len(chunk_ids) != len(set(chunk_ids)):
            raise ValueError("reranker candidates must have unique chunk IDs")
        pairs = [(question, candidate.chunk.text) for candidate in candidates]
        raw_scores = self._model.predict(
            pairs,
            batch_size=self.batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
            device=self.device,
        )
        scores = [float(score) for score in raw_scores]
        if len(scores) != len(candidates) or any(not math.isfinite(score) for score in scores):
            raise ValueError("reranker returned invalid scores")
        scored = list(zip(candidates, scores, strict=True))
        scored.sort(key=lambda item: (-item[1], item[0].rank, item[0].chunk.chunk_id))
        return [
            RetrievalResult(
                chunk=candidate.chunk,
                score=score,
                rank=rank,
                strategy="cross_encoder_rerank",
            )
            for rank, (candidate, score) in enumerate(scored[:top_k], start=1)
        ]


class RerankedRetriever:
    """Retrieve a bounded candidate set and rerank it with a cross-encoder."""

    def __init__(
        self,
        base_retriever: RetrievalProtocol,
        reranker: CrossEncoderReranker,
        *,
        candidate_k: int = 20,
    ) -> None:
        if candidate_k <= 0:
            raise ValueError("candidate_k must be positive")
        self._base_retriever = base_retriever
        self._reranker = reranker
        self.candidate_k = candidate_k

    def retrieve(self, question: str, *, top_k: int = 5) -> list[RetrievalResult]:
        candidates = self._base_retriever.retrieve(
            question,
            top_k=max(self.candidate_k, top_k),
        )
        return self._reranker.rerank(question, candidates, top_k=top_k)
