"""FastAPI interface for the citation-grounded RAG application."""

from __future__ import annotations

from collections.abc import Callable
from contextlib import asynccontextmanager
import os

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from rag_mvp.service import RAGService, ServiceInfo, ServiceSettings
from rag_mvp.vector_store import VectorSearchResult


class QueryRequest(BaseModel):
    """Validated request shared by retrieval and answer endpoints."""

    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=1, max_length=2_000)
    top_k: int | None = Field(default=None, ge=1, le=20)


class EvidenceResponse(BaseModel):
    """One ranked evidence chunk returned to an API caller."""

    chunk_id: str
    source_path: str
    title_or_section: str | None
    text: str
    score: float
    rank: int


class ClaimResponse(BaseModel):
    """One answer claim with its supporting chunk identifiers."""

    text: str
    citations: list[str]


class AnswerResponse(BaseModel):
    """Grounded answer and the exact retrieved evidence used to produce it."""

    profile: str
    question: str
    answer: str
    citations: list[str]
    claims: list[ClaimResponse]
    evidence: list[EvidenceResponse]


class RetrievalResponse(BaseModel):
    """Ranked evidence for retrieval inspection and debugging."""

    profile: str
    question: str
    evidence: list[EvidenceResponse]


class ReadinessResponse(BaseModel):
    """Loaded runtime profile and index metadata."""

    status: str
    profile: str
    embedding_provider: str
    generator_provider: str
    retrieval_strategy: str
    selected_configuration: str | None
    index_dimension: int | None
    chunk_count: int


class _ServiceContainer:
    def __init__(self, factory: Callable[[], RAGService]) -> None:
        self._factory = factory
        self.service: RAGService | None = None
        self.error: str | None = None

    def initialize(self) -> None:
        try:
            self.service = self._factory()
            self.error = None
        except Exception as error:
            self.service = None
            self.error = f"{type(error).__name__}: {error}"

    def require_service(self) -> RAGService:
        if self.service is None:
            raise HTTPException(
                status_code=503,
                detail={"code": "service_not_ready", "reason": self.error or "not initialized"},
            )
        return self.service


def create_app(
    service_factory: Callable[[], RAGService] | None = None,
) -> FastAPI:
    """Create an application with an injectable service factory."""

    factory = service_factory or (lambda: RAGService.from_settings(ServiceSettings.from_environment()))
    container = _ServiceContainer(factory)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        container.initialize()
        yield

    application = FastAPI(
        title="Citation-Grounded RAG API",
        version="0.2.0",
        description="Evidence-first retrieval and grounded answer generation with explicit citations.",
        lifespan=lifespan,
    )

    @application.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @application.get(
        "/ready",
        response_model=ReadinessResponse,
        responses={503: {"description": "Index or provider initialization failed."}},
    )
    def ready() -> ReadinessResponse:
        service = container.require_service()
        return _readiness_response(service.info)

    @application.post("/v1/retrieve", response_model=RetrievalResponse)
    def retrieve(request: QueryRequest) -> RetrievalResponse:
        service = container.require_service()
        try:
            results = service.retrieve(request.question, top_k=request.top_k)
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from error
        return RetrievalResponse(
            profile=service.info.profile,
            question=request.question,
            evidence=[_evidence_response(result) for result in results],
        )

    @application.post("/v1/answer", response_model=AnswerResponse)
    def answer(request: QueryRequest) -> AnswerResponse:
        service = container.require_service()
        try:
            result = service.answer(request.question, top_k=request.top_k)
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from error
        return AnswerResponse(
            profile=service.info.profile,
            question=result.answer.question,
            answer=result.answer.text,
            citations=result.answer.citations,
            claims=[
                ClaimResponse(text=claim.text, citations=claim.citations)
                for claim in result.answer.claims
            ],
            evidence=[_evidence_response(item) for item in result.evidence],
        )

    return application


def run() -> None:
    """Run the API using host and port values from the environment."""

    import uvicorn

    uvicorn.run(
        "rag_mvp.api:app",
        host=os.getenv("RAG_HOST", "127.0.0.1"),
        port=int(os.getenv("RAG_PORT", "8000")),
    )


def _readiness_response(info: ServiceInfo) -> ReadinessResponse:
    return ReadinessResponse(status="ready", **info.__dict__)


def _evidence_response(result: VectorSearchResult) -> EvidenceResponse:
    return EvidenceResponse(
        chunk_id=result.chunk.chunk_id,
        source_path=result.chunk.source_path,
        title_or_section=result.chunk.title_or_section,
        text=result.chunk.text,
        score=result.score,
        rank=result.rank,
    )


app = create_app()
