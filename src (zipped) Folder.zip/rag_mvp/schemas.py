"""Shared data structures for documents, chunks, retrieval results, and evaluations."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Document:
    """A source document loaded from the corpus."""

    source_id: str
    source_path: str
    text: str
    title: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.source_id:
            raise ValueError("source_id must not be empty")
        if not self.source_path:
            raise ValueError("source_path must not be empty")


@dataclass(frozen=True)
class Chunk:
    """A retrievable text segment with source traceability."""

    chunk_id: str
    source_id: str
    source_path: str
    text: str
    token_start: int
    token_end: int
    title_or_section: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.chunk_id:
            raise ValueError("chunk_id must not be empty")
        if not self.source_id:
            raise ValueError("source_id must not be empty")
        if self.token_start < 0:
            raise ValueError("token_start must be non-negative")
        if self.token_end <= self.token_start:
            raise ValueError("token_end must be greater than token_start")
        if not self.text.strip():
            raise ValueError("chunk text must not be empty")


@dataclass(frozen=True)
class RetrievalResult:
    """One ranked retrieval result shared by dense, lexical, and fused systems."""

    chunk: Chunk
    score: float
    rank: int
    strategy: str = "dense"

    def __post_init__(self) -> None:
        if self.rank <= 0:
            raise ValueError("rank must be positive")
        if not self.strategy:
            raise ValueError("strategy must not be empty")


@dataclass(frozen=True)
class AnswerClaim:
    """One answer claim and the chunks cited for that claim."""

    text: str
    citations: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.text.strip():
            raise ValueError("claim text must not be empty")


@dataclass(frozen=True)
class Answer:
    """A generated answer and its cited source chunks."""

    question: str
    text: str
    citations: list[str] = field(default_factory=list)
    retrieved_chunks: list[str] = field(default_factory=list)
    claims: list[AnswerClaim] = field(default_factory=list)


@dataclass(frozen=True)
class EvaluationCase:
    """One seed question for RAG evaluation."""

    question_id: str
    question: str
    expected_chunks: list[str] = field(default_factory=list)
    expected_answer: str | None = None
    requires_insufficient_evidence: bool = False
    question_type: str | None = None
    notes: str | None = None

    def __post_init__(self) -> None:
        if not self.question_id:
            raise ValueError("question_id must not be empty")
        if not self.question:
            raise ValueError("question must not be empty")


@dataclass(frozen=True)
class EvaluationResult:
    """Evaluation output for one question."""

    question_id: str
    question: str
    expected_chunks: list[str]
    retrieved_chunks: list[str]
    recall_hit: bool
    answer: str
    citations: list[str]
    citation_supported: bool
    answer_validation_passed: bool = True
    answer_validation_errors: list[str] = field(default_factory=list)
    quality_judgment: dict[str, object] | None = None
    insufficient_evidence_correct: bool | None = None
    notes: str | None = None
