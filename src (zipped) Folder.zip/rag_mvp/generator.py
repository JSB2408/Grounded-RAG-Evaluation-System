"""LLM generation interface."""

from __future__ import annotations

import json
import os
import re
from typing import Protocol

from rag_mvp.citations import extract_citations
from rag_mvp.prompt_builder import build_prompt
from rag_mvp.schemas import Answer, AnswerClaim
from rag_mvp.vector_store import VectorSearchResult


INSUFFICIENT_EVIDENCE_MESSAGE = "Insufficient evidence in the provided context."


class Generator(Protocol):
    """Answer generator interface."""

    def generate(self, question: str, retrieved_results: list[VectorSearchResult]) -> Answer:
        """Generate an answer from a question and retrieved chunks."""


class TemplateGroundedGenerator:
    """Local evidence-only generator for running the MVP without external APIs."""

    def __init__(self, *, min_score: float = 0.05, max_chunks: int = 3) -> None:
        self.min_score = min_score
        self.max_chunks = max_chunks

    def generate(self, question: str, retrieved_results: list[VectorSearchResult]) -> Answer:
        if not question.strip():
            raise ValueError("question must not be empty")

        usable_results = [
        result
        for result in retrieved_results[: self.max_chunks]
        if result.score >= self.min_score
        and _has_question_overlap(question, result.chunk.text)
]
        if not usable_results:
            return Answer(
                question=question,
                text=INSUFFICIENT_EVIDENCE_MESSAGE,
                citations=[],
                retrieved_chunks=[result.chunk.chunk_id for result in retrieved_results],
            )

        claims = []
        for result in usable_results:
            chunk = result.chunk
            evidence = _first_sentence(chunk.text)
            claims.append(AnswerClaim(text=evidence, citations=[chunk.chunk_id]))

        citations = _dedupe_citations(citation for claim in claims for citation in claim.citations)
        return Answer(
            question=question,
            text=_render_claims(claims),
            citations=citations,
            retrieved_chunks=[result.chunk.chunk_id for result in retrieved_results],
            claims=claims,
        )


class OpenAIGroundedGenerator:
    """OpenAI-backed generator for grounded answers from retrieved context."""

    def __init__(
        self,
        *,
        model: str = "gpt-4.1-mini",
        api_key: str | None = None,
        max_output_tokens: int = 700,
        temperature: float = 0.0,
        client: object | None = None,
    ) -> None:
        if not model:
            raise ValueError("model must not be empty")
        if max_output_tokens <= 0:
            raise ValueError("max_output_tokens must be positive")
        self.model = model
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        if client is not None:
            self._client = client
            return

        resolved_api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not resolved_api_key:
            raise ValueError("OPENAI_API_KEY must be set to use OpenAI generation")

        try:
            import importlib

            openai_module = importlib.import_module("openai")
        except ImportError as error:
            raise RuntimeError(
                "openai package is required for OpenAI generation. "
                "Install project dependencies with `python -m pip install -e .`."
            ) from error

        self._client = openai_module.OpenAI(api_key=resolved_api_key)

    def generate(self, question: str, retrieved_results: list[VectorSearchResult]) -> Answer:
        if not question.strip():
            raise ValueError("question must not be empty")

        prompt = build_prompt(question, retrieved_results)
        response = self._client.responses.create(
            model=self.model,
            input=prompt,
            max_output_tokens=self.max_output_tokens,
            temperature=self.temperature,
        )
        response_text = _extract_response_text(response)
        return _parse_grounded_answer(
            question,
            response_text,
            [result.chunk.chunk_id for result in retrieved_results],
        )


def create_generator(
    provider: str,
    *,
    model: str | None = None,
) -> Generator:
    """Create an answer generator by name."""

    normalized_provider = provider.strip().lower()
    if normalized_provider == "template":
        return TemplateGroundedGenerator()
    if normalized_provider == "openai":
        return OpenAIGroundedGenerator(model=model or "gpt-4.1-mini")
    raise ValueError(f"unsupported generator provider: {provider}")


def _first_sentence(text: str) -> str:
    compact = " ".join(text.split())
    if not compact:
        return ""
    match = re.search(r"(.+?[.!?。！？])(?:\s|$)", compact)
    if match:
        return match.group(1).strip()
    return compact[:300]


def _extract_response_text(response: object) -> str:
    output_text = getattr(response, "output_text", None)
    if isinstance(output_text, str) and output_text.strip():
        return output_text.strip()
    raise RuntimeError("OpenAI response did not contain text output")


def _parse_grounded_answer(
    question: str,
    response_text: str,
    retrieved_chunk_ids: list[str],
) -> Answer:
    json_text = _extract_json_text(response_text)
    try:
        payload = json.loads(json_text)
    except json.JSONDecodeError:
        return Answer(
            question=question,
            text=response_text,
            citations=extract_citations(response_text),
            retrieved_chunks=retrieved_chunk_ids,
        )

    status = str(payload.get("status", "")).strip()
    if status == "insufficient_evidence":
        return Answer(
            question=question,
            text=INSUFFICIENT_EVIDENCE_MESSAGE,
            citations=[],
            retrieved_chunks=retrieved_chunk_ids,
        )

    claims = _parse_claims(payload.get("claims", []))
    citations = _dedupe_citations(citation for claim in claims for citation in claim.citations)
    if claims:
        answer_text = _render_claims(claims)
    else:
        answer_text = str(payload.get("answer", "")).strip() or response_text
    return Answer(
        question=question,
        text=answer_text,
        citations=citations or extract_citations(answer_text),
        retrieved_chunks=retrieved_chunk_ids,
        claims=claims,
    )


def _parse_claims(raw_claims: object) -> list[AnswerClaim]:
    if not isinstance(raw_claims, list):
        return []

    claims: list[AnswerClaim] = []
    for raw_claim in raw_claims:
        if not isinstance(raw_claim, dict):
            continue
        text = str(raw_claim.get("text", "")).strip()
        raw_citations = raw_claim.get("citations", [])
        if not text or not isinstance(raw_citations, list):
            continue
        citations = [str(citation).strip() for citation in raw_citations if str(citation).strip()]
        claims.append(AnswerClaim(text=text, citations=citations))
    return claims


def _render_claims(claims: list[AnswerClaim]) -> str:
    return "\n".join(
        f"{claim.text} {' '.join(f'[{citation}]' for citation in claim.citations)}".strip()
        for claim in claims
    )


def _dedupe_citations(citations) -> list[str]:
    return list(dict.fromkeys(citations))


def _extract_json_text(text: str) -> str:
    compact = text.strip()
    if compact.startswith("```"):
        lines = compact.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        return "\n".join(lines).strip()
    return compact


def _has_question_overlap(question: str, evidence: str) -> bool:
    """Check for meaningful lexical overlap between question and evidence."""
    stop_words = {
        "a", "an", "and", "are", "as", "at", "be", "by", "do", "does",
        "for", "from", "how", "in", "is", "it", "of", "on", "or",
        "the", "to", "what", "when", "where", "which", "who", "why",
        "with",
    }

    question_terms = {
        token.lower()
        for token in re.findall(r"[A-Za-z0-9]+", question)
        if token.lower() not in stop_words
    }
    evidence_terms = {
        token.lower()
        for token in re.findall(r"[A-Za-z0-9]+", evidence)
        if token.lower() not in stop_words
    }

    overlap = question_terms & evidence_terms

    if not overlap:
        return False

# Reject a lone entity-name match when the question asks for a specific fact.
    if len(overlap) == 1 and re.search(
    r"\b(capital|population|founder|date|price|cause|definition)\b",
    question,
    re.IGNORECASE,
    ):
     return False

    return True