"""Fail-closed Codex CLI adapter for the frozen R7 semantic evaluation."""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Iterable

from rag_mvp.freeze_guard import sha256_file


REJECTED_ITEM_TYPES = {
    "command_execution",
    "file_change",
    "mcp_tool_call",
    "web_search",
    "computer_use",
}


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"expected JSON object at {path}:{line_number}")
        rows.append(value)
    return rows


def write_json(path: Path, value: dict[str, Any], *, exclusive: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = "x" if exclusive else "w"
    with path.open(mode, encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def validate_authorized_request(
    request_path: Path,
    authorization_path: Path,
    *,
    expected_sequence: int = 1,
) -> dict[str, Any]:
    request = load_json(request_path)
    authorization = load_json(authorization_path)
    actual_hash = sha256_file(request_path)
    if authorization.get("request_sha256") != actual_hash:
        raise PermissionError("R7 authorization request hash mismatch")
    if authorization.get("sequence") != expected_sequence:
        raise PermissionError("R7 authorization sequence mismatch")
    if int(request.get("sequence", 1)) != expected_sequence:
        raise PermissionError("R7 request sequence mismatch")
    if request.get("status") != "awaiting_exact_learner_authorization":
        raise PermissionError("unexpected R7 request status")
    if request["provider"].get("openai_api_calls_allowed") is not False:
        raise PermissionError("R7 request unexpectedly permits API calls")
    for section in ("frozen_inputs", "prompt_and_schema_bindings"):
        for entry in request[section].values():
            if not isinstance(entry, dict) or "path" not in entry:
                continue
            path = Path(str(entry["path"]))
            if not path.is_file() or sha256_file(path) != entry.get("sha256"):
                raise PermissionError(f"R7 bound artifact mismatch: {path}")
    return request


def batched(records: list[dict[str, Any]], size: int) -> list[list[dict[str, Any]]]:
    if size <= 0:
        raise ValueError("batch size must be positive")
    return [records[start : start + size] for start in range(0, len(records), size)]


def calibration_inputs(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "case_id": row["case_id"],
            "question": row["question"],
            "reference_contract": row["reference_contract"],
            "evidence": row["evidence"],
            "candidate": row["candidate"],
        }
        for row in records
    ]


def generation_inputs(
    cases: list[dict[str, Any]], retrieval_report: dict[str, Any], chunks: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    retrieval = {str(row["case_id"]): row for row in retrieval_report["cases"]}
    catalog = {str(row["chunk_id"]): row for row in chunks}
    if len(retrieval) != len(cases) or len(catalog) != len(chunks):
        raise ValueError("R7 retrieval or chunk identity mismatch")
    inputs = []
    for case in cases:
        case_id = str(case["case_id"])
        report_row = retrieval.get(case_id)
        if report_row is None:
            raise ValueError(f"missing frozen retrieval row: {case_id}")
        evidence = []
        for chunk_id in report_row["retrieved_ids"][:5]:
            chunk = catalog.get(str(chunk_id))
            if chunk is None:
                raise ValueError(f"missing frozen chunk: {chunk_id}")
            evidence.append(
                {
                    "chunk_id": chunk_id,
                    "source_path": chunk["source_path"],
                    "text": chunk["text"],
                }
            )
        inputs.append({"case_id": case_id, "question": case["question"], "evidence": evidence})
    return inputs


def judge_inputs(
    cases: list[dict[str, Any]], generation: list[dict[str, Any]], generation_input: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    case_map = {str(row["case_id"]): row for row in cases}
    input_map = {str(row["case_id"]): row for row in generation_input}
    rows = []
    for candidate in generation:
        case_id = str(candidate["case_id"])
        case = case_map[case_id]
        rows.append(
            {
                "case_id": case_id,
                "question": case["question"],
                "reference_contract": {
                    "required_claims": case["required_claims"],
                    "evidence_status": case["evidence_status"],
                    "requires_refusal": case["requires_refusal"],
                    "acceptable_answer_boundary": case["acceptable_answer_boundary"],
                },
                "evidence": input_map[case_id]["evidence"],
                "candidate": candidate,
            }
        )
    return rows


def _collect_types(value: Any) -> Iterable[str]:
    if isinstance(value, dict):
        item_type = value.get("type")
        if isinstance(item_type, str):
            yield item_type
        for child in value.values():
            yield from _collect_types(child)
    elif isinstance(value, list):
        for child in value:
            yield from _collect_types(child)


def _collect_usage(value: Any) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    if isinstance(value, dict):
        usage = value.get("usage")
        if isinstance(usage, dict):
            found.append(usage)
        for child in value.values():
            found.extend(_collect_usage(child))
    elif isinstance(value, list):
        for child in value:
            found.extend(_collect_usage(child))
    return found


def run_codex_batch(
    *,
    label: str,
    contract_path: Path,
    schema_path: Path,
    inputs: list[dict[str, Any]],
    model: str,
    reasoning_effort: str,
    output_root: Path,
    project_root: Path,
    timeout_seconds: int = 1200,
) -> dict[str, Any]:
    if not 1 <= len(inputs) <= 5:
        raise ValueError("Codex batch must contain one to five cases")
    output_root.mkdir(parents=True, exist_ok=True)
    input_path = output_root / f"{label}.input.json"
    events_path = output_root / f"{label}.events.jsonl"
    stderr_path = output_root / f"{label}.stderr.txt"
    final_path = output_root / f"{label}.final.json"
    metadata_path = output_root / f"{label}.metadata.json"
    for path in (input_path, events_path, stderr_path, final_path, metadata_path):
        if path.exists():
            raise PermissionError(f"refusing to overwrite prior R7 batch artifact: {path}")
    write_json(input_path, {"cases": inputs}, exclusive=True)
    prompt = (
        contract_path.read_text(encoding="utf-8")
        + "\n\nINPUT CASES JSON:\n"
        + json.dumps({"cases": inputs}, ensure_ascii=False)
    )
    command = [
        "codex",
        "exec",
        "--ephemeral",
        "--ignore-user-config",
        "--ignore-rules",
        "--model",
        model,
        "--config",
        f'model_reasoning_effort="{reasoning_effort}"',
        "--sandbox",
        "read-only",
        "--output-schema",
        str(schema_path.resolve()),
        "--color",
        "never",
        "--json",
        "--output-last-message",
        str(final_path.resolve()),
        "-",
    ]
    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8"
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            cwd=project_root,
            env=environment,
            input=prompt,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as error:
        stderr_path.write_text(str(error) + "\n", encoding="utf-8")
        raise RuntimeError(f"Codex batch timed out: {label}") from error
    elapsed = time.perf_counter() - started
    events_path.write_text(completed.stdout, encoding="utf-8")
    stderr_path.write_text(completed.stderr, encoding="utf-8")
    if completed.returncode != 0:
        raise RuntimeError(f"Codex batch failed with exit code {completed.returncode}: {label}")
    if not final_path.is_file():
        raise RuntimeError(f"Codex batch produced no final output: {label}")
    response = load_json(final_path)
    events = [json.loads(line) for line in completed.stdout.splitlines() if line.strip()]
    used_types = set(_collect_types(events))
    rejected = sorted(used_types & REJECTED_ITEM_TYPES)
    if rejected:
        raise PermissionError(f"Codex batch used prohibited tools: {rejected}")
    usage_records = _collect_usage(events)
    metadata = {
        "label": label,
        "model": model,
        "reasoning_effort": reasoning_effort,
        "case_ids": [row["case_id"] for row in inputs],
        "elapsed_seconds": elapsed,
        "exit_code": completed.returncode,
        "event_types": sorted(used_types),
        "usage_records": usage_records,
        "files": {
            "input_sha256": sha256_file(input_path),
            "events_sha256": sha256_file(events_path),
            "stderr_sha256": sha256_file(stderr_path),
            "final_sha256": sha256_file(final_path),
        },
    }
    write_json(metadata_path, metadata, exclusive=True)
    return {"response": response, "metadata": metadata}


def validate_result_ids(response: dict[str, Any], expected_ids: list[str]) -> list[dict[str, Any]]:
    results = response.get("results")
    if not isinstance(results, list):
        raise ValueError("batch response has no results list")
    actual_ids = [str(row.get("case_id")) for row in results if isinstance(row, dict)]
    if actual_ids != expected_ids or len(results) != len(expected_ids):
        raise ValueError(f"batch result identity/order mismatch: {actual_ids} != {expected_ids}")
    return results


def generation_validation_errors(result: dict[str, Any], supplied: dict[str, Any]) -> list[str]:
    errors = []
    status = result.get("status")
    claims = result.get("claims")
    if not isinstance(claims, list):
        return ["claims is not a list"]
    if status == "answered" and not claims:
        errors.append("answered result has no claims")
    if status == "insufficient_evidence" and claims:
        errors.append("insufficient-evidence result contains claims")
    available = {str(row["chunk_id"]) for row in supplied["evidence"]}
    for index, claim in enumerate(claims, 1):
        citations = claim.get("citations", []) if isinstance(claim, dict) else []
        if len(citations) != len(set(str(citation) for citation in citations)):
            errors.append(f"claim {index} contains duplicate citations")
        if any(str(citation) not in available for citation in citations):
            errors.append(f"claim {index} cites evidence outside supplied top-5")
    return errors


def judge_validation_errors(result: dict[str, Any]) -> list[str]:
    errors = []
    scores = result.get("scores", {})
    critical = result.get("critical_issues", [])
    required = (
        "factual_correctness",
        "completeness",
        "citation_precision",
        "abstention_correctness",
    )
    derived_pass = all(int(scores.get(name, 0)) >= 4 for name in required) and not critical
    if bool(result.get("overall_passed")) != derived_pass:
        errors.append("overall_passed conflicts with rubric threshold")
    return errors
