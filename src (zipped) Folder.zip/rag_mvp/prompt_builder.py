"""Prompt construction with retrieved context and citation requirements."""

from __future__ import annotations

from rag_mvp.vector_store import VectorSearchResult


SYSTEM_INSTRUCTION = """You are a citation-grounded RAG assistant.
Answer only using the provided context.
Cite only chunks that directly support the specific claim.
Answer with at most 3 concise claims.
Use at most 2 citations per claim.
Before answering, choose the evidence status:
- answered: the context directly states the requested fact, or directly states that the requested item or its immediate parent decision is not set, not selected, not committed, deferred, or still an open question.
- insufficient_evidence: the context only mentions the broad topic or future work, but does not directly support either the requested fact or a negative fact about that requested item.
Return JSON only, with this schema:
{
  "status": "answered" | "insufficient_evidence",
  "answer": "short answer without inline citations",
  "claims": [
    {"text": "one concise claim", "citations": ["chunk_id"]}
  ]
}
For status "answered", every claim must have at least one directly supporting chunk ID.
Evidence of absence counts as answerable: if the context states that a value is not set, not selected, not committed, deferred, or still an open question, answer that negative fact with direct citations instead of using insufficient_evidence.
For "which/what has been selected" questions, explicitly state "No ... has been selected" when the context supports that no selection has been made.
Prefer source/spec chunks that directly answer the question over broad current-state summaries.
Do not infer "not selected" merely because the context fails to mention a selection.
Example: if a question asks for a selected benchmark dataset and the context only says model training is later work, use insufficient_evidence.
Example: if a question asks for a production database and the context says database/deployment work is deferred, answer that no production database has been selected and cite the deferred-scope chunk.
For status "insufficient_evidence", set answer exactly to "Insufficient evidence in the provided context." and claims to []."""


def build_prompt(question: str, retrieved_results: list[VectorSearchResult]) -> str:
    """Build a prompt with chunk IDs and citation requirements."""

    if not question.strip():
        raise ValueError("question must not be empty")

    context_blocks = []
    for result in retrieved_results:
        chunk = result.chunk
        context_blocks.append(
            "\n".join(
                [
                    f"[{chunk.chunk_id}]",
                    f"Source: {chunk.source_path}",
                    f"Score: {result.score:.4f}",
                    chunk.text,
                ]
            )
        )

    context = "\n\n".join(context_blocks) if context_blocks else "(No context retrieved.)"
    return "\n\n".join(
        [
            f"System instruction:\n{SYSTEM_INSTRUCTION}",
            f"Context:\n{context}",
            f"Question:\n{question}",
            "Answer:",
        ]
    )
