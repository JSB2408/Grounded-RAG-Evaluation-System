"""Embedding provider interface."""

from __future__ import annotations

from collections.abc import Sequence
import hashlib
import os
import re
from typing import Protocol

import numpy as np
from numpy.typing import NDArray


FloatMatrix = NDArray[np.float32]
FloatVector = NDArray[np.float32]


class EmbeddingProvider(Protocol):
    """Provider interface for text embedding models."""

    def embed_texts(self, texts: Sequence[str]) -> FloatMatrix:
        """Embed multiple texts into a 2D float32 matrix."""

    def embed_query(self, text: str) -> FloatVector:
        """Embed one query into a 1D float32 vector."""


class LocalHashEmbeddingProvider:
    """Deterministic local embedding baseline for development and tests."""

    def __init__(self, dimension: int = 384) -> None:
        if dimension <= 0:
            raise ValueError("dimension must be positive")
        self.dimension = dimension

    def embed_texts(self, texts: Sequence[str]) -> FloatMatrix:
        if not texts:
            raise ValueError("texts must not be empty")
        return as_float_matrix([self._embed_one(text) for text in texts])

    def embed_query(self, text: str) -> FloatVector:
        return as_float_vector(self._embed_one(text))

    def _embed_one(self, text: str) -> FloatVector:
        tokens = _tokenize_for_hash_embedding(text)
        if not tokens:
            raise ValueError("cannot embed empty text")

        vector = np.zeros(self.dimension, dtype=np.float32)
        for token in tokens:
            digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
            value = int.from_bytes(digest, byteorder="big", signed=False)
            index = value % self.dimension
            sign = 1.0 if ((value >> 1) & 1) == 0 else -1.0
            vector[index] += sign
        return vector


class SentenceTransformerEmbeddingProvider:
    """Pinned local Sentence-Transformers Bi-Encoder provider."""

    def __init__(
        self,
        *,
        model: object | None = None,
        model_dir: str | None = None,
        device: str = "cpu",
        batch_size: int = 32,
        expected_dimension: int = 384,
    ) -> None:
        if batch_size <= 0 or expected_dimension <= 0:
            raise ValueError("batch_size and expected_dimension must be positive")
        self.device = device
        self.batch_size = batch_size
        self.dimension = expected_dimension
        if model is not None:
            self._model = model
        else:
            if not model_dir:
                raise ValueError("model_dir is required for local semantic embeddings")
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer(
                model_dir,
                device=device,
                local_files_only=True,
                trust_remote_code=False,
            )
        reported_dimension = int(self._model.get_sentence_embedding_dimension())
        if reported_dimension != expected_dimension:
            raise ValueError(
                f"embedding dimension {reported_dimension} does not match "
                f"expected dimension {expected_dimension}"
            )

    def embed_texts(self, texts: Sequence[str]) -> FloatMatrix:
        if not texts:
            raise ValueError("texts must not be empty")
        if any(not text.strip() for text in texts):
            raise ValueError("embedding texts must not be empty")
        vectors = self._model.encode(
            list(texts),
            batch_size=self.batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
            device=self.device,
        )
        matrix = as_float_matrix(vectors)
        if matrix.shape[1] != self.dimension:
            raise ValueError(
                f"embedding output dimension {matrix.shape[1]} does not match {self.dimension}"
            )
        return matrix

    def embed_query(self, text: str) -> FloatVector:
        return self.embed_texts([text])[0]


def _tokenize_for_hash_embedding(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9]+|[\u4e00-\u9fff]", text.lower())


class OpenAIEmbeddingProvider:
    """OpenAI embedding provider backed by the official Python SDK."""

    def __init__(
        self,
        *,
        model: str = "text-embedding-3-small",
        api_key: str | None = None,
        batch_size: int = 128,
        client: object | None = None,
    ) -> None:
        if not model:
            raise ValueError("model must not be empty")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        self.model = model
        self.batch_size = batch_size
        if client is not None:
            self._client = client
            return

        resolved_api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not resolved_api_key:
            raise ValueError("OPENAI_API_KEY must be set to use OpenAI embeddings")

        try:
            from openai import OpenAI
        except ImportError as error:
            raise RuntimeError(
                "openai package is required for OpenAI embeddings. "
                "Install project dependencies with `python -m pip install -e .`."
            ) from error

        self._client = OpenAI(api_key=resolved_api_key)

    def embed_texts(self, texts: Sequence[str]) -> FloatMatrix:
        if not texts:
            raise ValueError("texts must not be empty")

        vectors: list[list[float]] = []
        for start in range(0, len(texts), self.batch_size):
            batch = list(texts[start : start + self.batch_size])
            response = self._client.embeddings.create(model=self.model, input=batch)
            vectors.extend([item.embedding for item in response.data])
        return as_float_matrix(vectors)

    def embed_query(self, text: str) -> FloatVector:
        return self.embed_texts([text])[0]


def create_embedding_provider(
    provider: str,
    *,
    model: str | None = None,
    dimension: int = 384,
) -> EmbeddingProvider:
    """Create an embedding provider by name."""

    normalized_provider = provider.strip().lower()
    if normalized_provider == "local-hash":
        return LocalHashEmbeddingProvider(dimension=dimension)
    if normalized_provider == "openai":
        return OpenAIEmbeddingProvider(model=model or "text-embedding-3-small")
    raise ValueError(f"unsupported embedding provider: {provider}")


def as_float_matrix(vectors: Sequence[Sequence[float]] | np.ndarray) -> FloatMatrix:
    """Convert vectors to a validated 2D float32 matrix."""

    matrix = np.asarray(vectors, dtype=np.float32)
    if matrix.ndim != 2:
        raise ValueError("embedding matrix must be 2-dimensional")
    if matrix.shape[0] == 0:
        raise ValueError("embedding matrix must contain at least one vector")
    if matrix.shape[1] == 0:
        raise ValueError("embedding dimension must be positive")
    if not np.isfinite(matrix).all():
        raise ValueError("embedding matrix must contain only finite values")
    return matrix


def as_float_vector(vector: Sequence[float] | np.ndarray) -> FloatVector:
    """Convert one vector to a validated 1D float32 array."""

    array = np.asarray(vector, dtype=np.float32)
    if array.ndim != 1:
        raise ValueError("embedding vector must be 1-dimensional")
    if array.shape[0] == 0:
        raise ValueError("embedding dimension must be positive")
    if not np.isfinite(array).all():
        raise ValueError("embedding vector must contain only finite values")
    return array


def normalize_matrix(vectors: Sequence[Sequence[float]] | np.ndarray) -> FloatMatrix:
    """Return L2-normalized vectors for cosine-similarity search."""

    matrix = as_float_matrix(vectors).copy()
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    if np.any(norms == 0):
        raise ValueError("embedding matrix must not contain zero vectors")
    return matrix / norms


def normalize_vector(vector: Sequence[float] | np.ndarray) -> FloatVector:
    """Return one L2-normalized vector for cosine-similarity search."""

    array = as_float_vector(vector).copy()
    norm = np.linalg.norm(array)
    if norm == 0:
        raise ValueError("embedding vector must not be a zero vector")
    return array / norm
