"""Document chunking and metadata preservation."""

from __future__ import annotations

import re
from dataclasses import dataclass
from collections.abc import Iterable

from rag_mvp.schemas import Chunk, Document


DEFAULT_CHUNK_SIZE = 500
DEFAULT_CHUNK_OVERLAP = 100

_TOKEN_PATTERN = re.compile(
    r"[A-Za-z0-9]+(?:['_-][A-Za-z0-9]+)*|[\u4e00-\u9fff]|[^\s]",
    re.UNICODE,
)


@dataclass(frozen=True)
class _TokenSpan:
    text: str
    start: int
    end: int


def chunk_documents(
    documents: Iterable[Document],
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[Chunk]:
    """Split documents into retrievable chunks."""

    chunks: list[Chunk] = []
    for document in documents:
        chunks.extend(
            chunk_document(
                document,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
            )
        )
    return chunks


def chunk_document(
    document: Document,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[Chunk]:
    """Split one document into overlapping chunks using approximate tokens."""

    _validate_chunk_settings(chunk_size, chunk_overlap)
    token_spans = _tokenize_with_spans(document.text)
    if not token_spans:
        return []

    chunks: list[Chunk] = []
    start_token = 0
    chunk_index = 0

    while start_token < len(token_spans):
        end_token = min(start_token + chunk_size, len(token_spans))
        start_char = token_spans[start_token].start
        end_char = token_spans[end_token - 1].end
        chunk_text = document.text[start_char:end_char].strip()

        if chunk_text:
            chunks.append(
                Chunk(
                    chunk_id=f"{document.source_id}_chunk_{chunk_index:04d}",
                    source_id=document.source_id,
                    source_path=document.source_path,
                    title_or_section=document.title,
                    text=chunk_text,
                    token_start=start_token,
                    token_end=end_token,
                    metadata={
                        **document.metadata,
                        "chunk_index": str(chunk_index),
                        "chunk_size": str(chunk_size),
                        "chunk_overlap": str(chunk_overlap),
                    },
                )
            )
            chunk_index += 1

        if end_token == len(token_spans):
            break
        start_token = end_token - chunk_overlap

    return chunks


def _validate_chunk_settings(chunk_size: int, chunk_overlap: int) -> None:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if chunk_overlap < 0:
        raise ValueError("chunk_overlap must be non-negative")
    if chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be smaller than chunk_size")


def _tokenize_with_spans(text: str) -> list[_TokenSpan]:
    return [
        _TokenSpan(match.group(0), match.start(), match.end())
        for match in _TOKEN_PATTERN.finditer(text)
    ]
