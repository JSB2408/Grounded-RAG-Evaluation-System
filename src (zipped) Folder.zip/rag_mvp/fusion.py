"""Rank fusion for combining independent retrieval systems."""

from __future__ import annotations

from collections.abc import Sequence

from rag_mvp.retriever import RetrievalProtocol
from rag_mvp.schemas import RetrievalResult


def reciprocal_rank_fusion(
    rankings: Sequence[Sequence[RetrievalResult]],
    *,
    top_k: int,
    rank_constant: int = 60,
) -> list[RetrievalResult]:
    """Fuse rankings with standard Reciprocal Rank Fusion."""

    if len(rankings) < 2:
        raise ValueError("at least two rankings are required")
    if top_k <= 0:
        raise ValueError("top_k must be positive")
    if rank_constant <= 0:
        raise ValueError("rank_constant must be positive")
    scores: dict[str, float] = {}
    chunks = {}
    best_ranks: dict[str, int] = {}
    for ranking in rankings:
        seen_in_ranking: set[str] = set()
        for result in ranking:
            chunk_id = result.chunk.chunk_id
            if chunk_id in seen_in_ranking:
                raise ValueError(f"duplicate chunk in one ranking: {chunk_id}")
            seen_in_ranking.add(chunk_id)
            chunks[chunk_id] = result.chunk
            scores[chunk_id] = scores.get(chunk_id, 0.0) + 1.0 / (
                rank_constant + result.rank
            )
            best_ranks[chunk_id] = min(best_ranks.get(chunk_id, result.rank), result.rank)
    ordered = sorted(
        scores,
        key=lambda chunk_id: (-scores[chunk_id], best_ranks[chunk_id], chunk_id),
    )[:top_k]
    return [
        RetrievalResult(
            chunk=chunks[chunk_id],
            score=scores[chunk_id],
            rank=rank,
            strategy="hybrid_rrf",
        )
        for rank, chunk_id in enumerate(ordered, start=1)
    ]


class HybridRetriever:
    """Retrieve a fixed candidate budget from two systems and fuse their ranks."""

    def __init__(
        self,
        first: RetrievalProtocol,
        second: RetrievalProtocol,
        *,
        candidate_k: int = 20,
        rank_constant: int = 60,
    ) -> None:
        if candidate_k <= 0:
            raise ValueError("candidate_k must be positive")
        self._first = first
        self._second = second
        self.candidate_k = candidate_k
        self.rank_constant = rank_constant

    def retrieve(self, question: str, *, top_k: int = 5) -> list[RetrievalResult]:
        if top_k <= 0:
            raise ValueError("top_k must be positive")
        budget = max(top_k, self.candidate_k)
        return reciprocal_rank_fusion(
            [
                self._first.retrieve(question, top_k=budget),
                self._second.retrieve(question, top_k=budget),
            ],
            top_k=top_k,
            rank_constant=self.rank_constant,
        )
