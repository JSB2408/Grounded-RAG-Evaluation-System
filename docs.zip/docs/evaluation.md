# Evaluation Evidence

## Design

Corpus v1 was frozen before case authoring. Evaluation v1 then fixed 20
development cases and 60 hard-test cases before BM25, Hybrid, or reranking
selection. Development data selected one retriever; frozen observations could
describe but never alter it.

The test set covers direct facts, paraphrases, high-similarity distractors,
cross-document synthesis, version boundaries, insufficient evidence, and
prompt injection. Each answerable case defines accepted evidence groups and
required claims. Each unanswerable case defines an explicit abstention
contract.

## Retrieval evaluation

Metrics include all-evidence and partial Recall@5/10, MRR, nDCG, zero-hit rate,
category slices, p50/p95 latency, and paired bootstrap intervals.

| Candidate | All Recall@5 | Partial Recall@5 | MRR@5 | nDCG@5 | p95 |
|---|---:|---:|---:|---:|---:|
| B0 Dense MiniLM | 0.558 | 0.620 | 0.519 | 0.523 | 9.24 ms |
| **B1 BM25** | **0.769** | **0.830** | **0.659** | **0.681** | **2.31 ms** |
| B2 Hybrid RRF | 0.769 | 0.820 | 0.647 | 0.667 | 11.50 ms |
| B3 Cross-Encoder | 0.692 | 0.747 | 0.653 | 0.652 | 891.68 ms |

B1 was selected on development before the one-time frozen run. B2 tied B1 on
frozen All Recall@5 but did not justify its additional latency and complexity.
B3 improved Recall@10 but moved required passages below the top-five generation
budget and was far slower on CPU.

## Semantic evaluation

R7 used the frozen B1 top-five evidence. Deterministic gates checked response
schema, case identity and order, claim/citation limits, citation availability,
duplicate citations, and refusal structure before the independent Judge.

The Judge rubric separated factual correctness, completeness, citation
precision, abstention correctness, and conciseness. Eight hidden-label
calibration cases required exact 8/8 agreement before formal access.

| Gate | Result |
|---|---:|
| Generation coverage | 60/60 |
| Machine-valid answers | 60/60 |
| Retrieval evidence | 48/60 |
| Abstention behavior | 56/60 |
| Judge pass | 45/60 |
| Strict system pass | 37/60 |

The strict system metric requires retrieval, deterministic generation,
abstention behavior, and semantic judgment to all pass. All eight true
insufficient-evidence cases were refused, while four sufficient cases were
over-refused. Cross-document synthesis was weakest at 2/10 strict passes.

## Failure taxonomy

- Retrieval missing required evidence: 12 cases.
- Semantic Judge failure: 15 cases.
- Incorrect abstention behavior: 4 cases.
- Machine-structure failure: 0 cases.

Failure types overlap. A generation failure is not relabeled as retrieval merely
because retrieval was also incomplete.

## Sequence history

- Sequence 1 stopped at Judge calibration 7/8 because one calibration evidence
  contract was ambiguous.
- Sequence 2 passed calibration 8/8 but stopped before inference when the
  provider rejected one JSON Schema keyword.
- Sequence 3 added a synthetic schema preflight, passed calibration 8/8, and
  completed exactly one formal attempt.

These failures are preserved because replacing them would hide important
evaluation-engineering lessons.

## Historical baseline

The original v0.2 project recorded three 30-case in-domain semantic runs with
30/30 on its then-current gates. That result is retained as historical evidence
but is not compared numerically with the harder 60-case set.

## Claim boundary

The evidence supports performance claims only for corpus-v1 and eval-v1. It does
not establish general-domain accuracy, production reliability, unbiased LLM
judging, immutable Codex model snapshots, or online serving performance.
