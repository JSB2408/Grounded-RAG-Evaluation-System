# Architecture and Engineering Decisions

## Product boundary

The application answers questions over a controlled technical corpus and
returns the ranked evidence used for each answer. It separates retrieval,
generation, deterministic validation, and semantic judgment so failures remain
diagnosable.

It is not an Agent. The product has one stable question-to-evidence-to-answer
workflow and no justified need for autonomous planning or tool selection.

## Serving plane

1. FastAPI validates `question` and `top_k`.
2. `RAGService` resolves an explicit runtime profile.
3. The default `portfolio` profile verifies the R5 configuration and frozen
   chunk SHA-256, then initializes BM25 over 515 chunks.
4. `/v1/retrieve` returns rank, score, text, chunk ID, and source path.
5. `/v1/answer` passes only retrieved evidence to the generator and returns
   claims, citations, and evidence.
6. `/health` represents process liveness; `/ready` represents dependency and
   configuration readiness.

## Evaluation plane

The evaluation plane is separate from serving:

- R2 freezes corpus sources, licenses, document hashes, and chunks.
- R3 freezes development and hard-test cases before retrieval alternatives.
- R4 implements Dense, BM25, RRF Hybrid, and Cross-Encoder candidates behind a
  shared interface.
- R5 selects one configuration using development cases only.
- R6 binds that configuration by hash and runs one frozen retrieval attempt.
- R7 runs deterministic answer gates before a calibrated independent Judge and
  seals raw outputs, tokens, latency, failure types, and hashes.

The R7 Codex CLI adapter is an evaluation backend, not the application serving
backend. It runs with no tools or web access and cannot change frozen inputs.

## Runtime profiles

| Profile | Retriever | Generator | Boundary |
|---|---|---|---|
| `portfolio` | Frozen B1 BM25 | Template | Default zero-key API and Docker path |
| `offline-demo` | Local-Hash FAISS | Template | Historical plumbing regression |
| `semantic` | OpenAI-built FAISS | OpenAI | Optional API-backed integration |

The `portfolio` profile fails readiness if either the selected-configuration
identity or chunks hash differs. `semantic` never silently rebuilds the saved
index. `offline-demo` writes only inside `.runtime/offline-demo/`.

## Failure handling

- Invalid requests fail with HTTP 422.
- Missing indexes, credentials, or frozen files keep liveness at 200 but close
  readiness with HTTP 503.
- Embedding/index dimension mismatch fails explicitly.
- Frozen evaluation attempts use exclusive state files and prohibit reruns.
- Model schema, case order, citation IDs, and rubric thresholds are validated
  before aggregation.
- Unfavorable results remain checked in and cannot change the selected system.

## Engineering trade-offs

- FAISS keeps dense retrieval mechanics visible; BM25 won the measured corpus
  comparison and therefore became the default portfolio path.
- Returning evidence improves debuggability but would require access control
  and redaction for sensitive production corpora.
- Direct LLM judging covers semantic qualities that rules cannot, but requires
  calibration and does not equal human ground truth.
- Local Docker verification demonstrates packaging and HTTP behavior, not
  production scalability.
